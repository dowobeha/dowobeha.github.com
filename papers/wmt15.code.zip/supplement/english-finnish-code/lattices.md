# Word Lattices using Morfessor
The `nbest-segment.py` tool here extracts word lattices from
newline-delimited Finnish sentences. The output is written to standard out
in [Python lattice format][plf], which Moses can decode directly.

[plf]: http://www.statmt.org/moses/?n=Moses.WordLattices
