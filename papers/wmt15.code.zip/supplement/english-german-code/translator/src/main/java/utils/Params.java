package utils;

public class Params {
	
	public static String cacheLoc = 
//			"/Users/subhroroy/translation_cache/";
			"/shared/bronte/sroy9/translation_cache/";
	public static String preprocessorConfig = "config/preprocessor.config";
	
}
