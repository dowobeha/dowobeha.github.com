package translator;

import java.io.BufferedReader;
import java.io.IOException;

import edu.illinois.cs.cogcomp.core.datastructures.Pair;

public class PairReader {

	private BufferedReader e;
	private BufferedReader f;

	public PairReader(BufferedReader f, BufferedReader e) {
		this.f=f;
		this.e=e;
	}
	Pair<String,String>next() throws IOException{
		String fline = f.readLine();
		String eline = e.readLine();
		if(fline==null || eline==null)
			return null;
		return new Pair<String, String>(fline, eline);
	}
}
