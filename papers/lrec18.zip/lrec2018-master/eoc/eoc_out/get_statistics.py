#!/usr/bin/python
# -*- coding: utf-8 -*-

# The script is designed to acquire various statistics from the txt files contained in the 'eoc_out' directory,
# which contains all words in the evaluation txt files
#
# Usage: ./get_statistics.py eoc_out/
# The script recursively processes each txt file, starting at the provided root directory

import os

d = {}

for filename in os.listdir(os.getcwd()):
	with open(filename, 'r') as f:
		lines = f.readlines()		

		word = ""
		num_analyses = 0

		for line in lines:
			line = line.strip()

			if not line:
				tup = (word, num_analyses)

				# Builds a dictionary where each key is a tuple: (word, # analyses)
				# and each value is the number of occurrences of that word across
				# all the txts in the root directory
				if tup in d:
					d[tup] += 1
				else:
					d[tup] = 1 

				word = ""
				num_analyses = 0

			elif "\t" in line:
				word = line.split("\t")[0]
				num_analyses += 1

# Print the dictionary
for k in d:
	print("{} => {}".format(str(k), str(d[k])))
'''
# Calculates average and median number of analyses per word
sum_analyses = 0
l = []
geq = []

for k in d:
	sum_analyses += int(k[1])
	l.append(int(k[1]))

	if k[1] > 200:
		geq.append(k)

sorted_l = sorted(l)

print "Sum of all analyses = " + str(sum_analyses)
print "Sum of all words = 796"
print "Average number of analyses per word = " + str(sum_analyses/796)
print "Median number of analyses per word = " + str(sorted_l[796/2])
print geq

# Print the number of words per number of analysis count
w_per_a = {}

for k in d:
	num_a = k[1]
	if num_a not in w_per_a:
		if num_a == 1:
			w_per_a[num_a] = -19	# To account for the 19 words without analyses
		else:
			w_per_a[num_a] = 1
	else:
		w_per_a[num_a] += 1

for k in w_per_a:
	print("{}\t{}".format(str(k), str(w_per_a[k])))
'''
