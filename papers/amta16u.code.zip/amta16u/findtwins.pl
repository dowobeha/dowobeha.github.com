#!/usr/bin/perl

# TODO:  
# utility to detect identical lines across parallel text
# these may be English vs. English-in-the-French,
# or they may be words which translate with cognates (portrait, portrait)
# or they may be named entities (Armenia, Armenia)
#
# set a threshold for degree of match at which to flag lines
# make an option to delete matching lines
# output matching lines to a file for inspection

use strict;
use POSIX;
use Getopt::Std;

binmode(STDOUT, ":utf8");

our($opt_i, $opt_j, $opt_o, $opt_p, $opt_m, $opt_t, $opt_l, $opt_d);
getopts("i:j:o:p:m:t:ld");

if(!$opt_i) {
    die "No first input file specified with -i!\n";
}
if(!$opt_j) {
    die "No second input file specified with -j!\n";
}
if(!$opt_o) {
    die "No output file specified with -o!\n";
}
if(!$opt_p) {
    die "No second output file specified with -p!\n";
}
if(!$opt_m) {
    die "No output file for listing matching lines specified with -m!\n";
}

open (INFILE, $opt_i) or die "$0: Unable to open input file: $opt_i\n";
open (INFILE2, $opt_j) or die "$0: Unable to open input file: $opt_j\n";


open (OUTFILE, ">$opt_o") or die "$0: Unable to open output file: $opt_o\n";
open (OUTFILE2, ">$opt_p") or die "$0: Unable to open second output file: $opt_p\n";
open (OUTFILEM, ">$opt_m") or die "$0: Unable to open matching lines output file: $opt_m\n";


binmode(INFILE, ":utf8");
binmode(INFILE2, ":utf8");
	
binmode(OUTFILE, ":utf8");
binmode(OUTFILE2, ":utf8");
binmode(OUTFILEM, ":utf8");


my $thresh = 100;
my $countlines = 0;
my $deletematches = 0;


if ($opt_t) {
$thresh = $opt_t;
} else {
print "no matching threshhold set with -t, defaulting to exact match\n";
} # end if threshhold specified

if ($opt_l) {
$countlines = 1;
} # end if line-counting option specified

if ($opt_d) {
$deletematches = 1;
} # end if delete option specified

print OUTFILEM "a list of lines in INFILE and INFILE2 which match at threshold $thresh or above\n\n";
print "matching threshold $thresh\n";
print "write line numbers? $countlines\n";
print "delete matching lines? $deletematches\n";


my @words1 = ();
my $row1;
my $wordcount1 = 0;

my @words2 = ();
my $row2;
my $wordcount2 = 0;

my $linenumber1 = 0;
my $linenumber2 = 0;


while($row1 = <INFILE>) {
$linenumber1++;

$wordcount1 = 0;
chomp $row1;
@words1 = split /\s+/, $row1;
foreach(@words1) {
  $wordcount1++;
} # end foreach

if ($row2 = <INFILE2>) {
$linenumber2++;

$wordcount2 = 0;
chomp $row2;
@words2 = split /\s+/, $row2;
foreach(@words2) {
  $wordcount2++;
} # end foreach



		if ($row1 eq $row2) {
#		print "exact match:\n$linenumber1//$row1\n$linenumber2//$row2\n";
		}

} else {
print "mismatched number of lines\n";
} # end if else have more lines in second file

# now compare the lines
my $percentmatch = 0;
my $matchcount = 0;
my $word1;
my $word2;

if (($wordcount1==0)&&($wordcount2==0)) {
# both blank -- so matching
$percentmatch = 1;

} elsif (($wordcount1==0)||($wordcount2==0)) {
# one line blank, one not
$percentmatch = 0;

} else {

if ($wordcount1>=$wordcount2) {

my $index = 0;
foreach $word1 (@words1) {
$word2 = @words2[$index];
$index++;
if ($word1 eq $word2) {
$matchcount++;
}

} # end for each word in row 1

$percentmatch = $matchcount / $wordcount1;
#print "percent match: $percentmatch\n";
} elsif ($wordcount2>$wordcount1) {

my $index = 0;
foreach $word2 (@words2) {
$word1 = @words1[$index];
$index++;
if ($word2 eq $word1) {
$matchcount++;
}

} # end for each word in row 2

$percentmatch = $matchcount / $wordcount2;
#print "percent match: $percentmatch\n";



} # end if else line one is longest (or equal)

} # end if else both blank, one blank, both text

# output

if ($percentmatch*100>=$thresh) {
	if ($countlines) {
	print OUTFILEM "$linenumber1//$row1\n$linenumber2//$row2\n\n";
	} else {
	print OUTFILEM "$row1\n$row2\n\n";
	} # end if print line numbers

	if (!$deletematches) {
	print OUTFILE "$row1\n";
	print OUTFILE2 "$row2\n";
	} # end if NOT deleting matched lines from outfiles
} else {
print OUTFILE "$row1\n";
print OUTFILE2 "$row2\n";
} # end if else good match

} # end while row1


close INFILE;
close INFILE2;
close OUTFILE;
close OUTFILE2;
close OUTFILEM;







