#!/usr/bin/perl
use Text::Aspell;
use encoding 'utf8';
use Getopt::Std;
# next line needed for output formatting
binmode(STDOUT, ":utf8");
# usage:  aspell-list-unk.pl -i <input> -o <output>
# counts proportion of words that are good English words, based on being recognized by Aspell
# only compares words of length >= 4 characters (to rule out false matches with words like die, in , is, a, si, et, le, se, tu, on, la, op, was, van ...

# FORMERLY:  lists any line with a sequence of unk words, n>4
# FORMERLY:  looking for pdf ciphers, in which pdf material is extracted like this:  wkhq wkdw dq\rqh fdg eh dq lqyhqwru 
# and other encodings, such as 
#... Aleksei Nikolaevich Tolstoi (Russian: ÐÐ»ÐµÐºÑÐµÐ¹ ÐÐ¸ÐºÐ¾Ð»Ð°ÐµÐ²Ð¸Ñ Ð¢Ð¾Ð»ÑÑÐ¾Ð¹)
#
# this version only compares words of length >= 4 characters (to rule out false matches with words like die, in , is, a, si, et, le, se, tu, on, la, op, was, van ...
#
#given a Russian file and an English file, checks the English file for non-English sentences, and removes them from both sides of the parallel text
# we replace these lines with blank lines, to preserve the line numbering (use removeBlankLines.pl if needed)

our($opt_e, $opt_r, $opt_n);
getopts("e:r:n:");
if(!$opt_e) {
    die "No English input file specified with -e!\n";
}
if(!$opt_r) {
    die "No Russian input file specified with -r!\n";
}
if(!$opt_n) {
    die "No required proportion of good English words per line specified with -n! (e.g., 50 for 50%)\n";
}

open (INRU, $opt_r) or die "$0: Unable to open input file: $opt_r\n";
open (INEN, $opt_e) or die "$0: Unable to open input file: $opt_e\n";
my $goodEnglish = $opt_e."-keepE-aspellChecked4CharMin".$opt_n."PercentEnglish";
my $badEnglish = $opt_e."-nonE-aspellChecked4CharMin".$opt_n."PercentEnglish";
my $goodRussian = $opt_r."-keepE-aspellChecked4CharMin".$opt_n."PercentEnglish-parallel";
my $badRussian = $opt_r."-nonE-aspellChecked4CharMin".$opt_n."PercentEnglish-parallel";
open (EGOODLINES, ">$goodEnglish") or die "$0: Unable to open output file: $goodEnglish\n";
open (EBADLINES, ">$badEnglish") or die "$0: Unable to open output file: $badEnglish\n";
open (RGOODLINES, ">$goodRussian") or die "$0: Unable to open output file: $goodRussian\n";
open (RBADLINES, ">$badRussian") or die "$0: Unable to open output file: $badRussian\n";
binmode(INEN, ":utf8");
binmode(INRU, ":utf8");
binmode(EGOODLINES, ":utf8");
binmode(EBADLINES, ":utf8");
binmode(RGOODLINES, ":utf8");
binmode(RBADLINES, ":utf8");
##############################


my $thresh = $opt_n/100;

my $speller = Text::Aspell->new;
die unless $speller;

# Set some options
$speller->set_option('lang','en_US');
#$speller->set_option('lang','fr');
$speller->set_option('sug-mode','slow');
$speller->set_option('ignore-case', 'true');

my $speller2 = Text::Aspell->new;
die unless $speller2;

# Set some options
#$speller2->set_option('lang','en_GB');
$speller2->set_option('lang','fr');
$speller2->set_option('sug-mode','slow');
$speller2->set_option('ignore-case', 'true');

my $kloc = '/home/youngkm/kjava/com/nspaceanalysis/utilities/Text-Aspell-0.09';
my $klocdatadir = $kloc.'/data';
#my $protecteddictionary = $klocdatadir.'/en_US-pakwords.rws';
#my $misspelledwordsdictionary = $klocdatadir.'/en_US-misspelledwords.rws';
my $mainloc = '/usr/lib/aspell-0.60';
#my $usmain = $mainloc.'/en_US-wo_accents-only.rws';
#my $gbmain = $mainloc.'/en_GB-ise-wo_accents-only.rws';

### maybe ### my $frmain = $mainloc.'/en_US-wo_accents-only.rws';

#$speller->set_option('add-extra-dicts', $protecteddictionary);
# #$speller->set_option('add-extra-dicts', $misspelledwordsdictionary);
#$speller->set_option('add-extra-dicts', $usmain);
#$speller->set_option('add-extra-dicts', $gbmain);

### maybe ### $speller->set_option('add-extra-dicts', $frmain);

#my $copyofUS = $klocdatadir.'/fr_US-wo_accents-only.rws';
#$speller->set_option('add-extra-dicts', $copyofUS);

my %nodupes;
my $line = 0; 
while (my $erow = <INEN>) {
my $rrow = <INRU>; 
$line++;
my $badcount = 0; 
my $wordcount = 0; 

chomp $erow;
chomp $rrow;

my $len = length($erow); 
if ($len > 0) {

print $erow."\n"; 
my $plainrow = $erow;
# discard html (matches Moses escaper); convert punctuation to space; convert digits to space
$plainrow =~ s/\&nbsp/ /g; 
$plainrow =~ s/\&quot/ /g; 
$plainrow =~ s/\&amp/ /g; 
$plainrow =~ s/\&lt/ /g; 
$plainrow =~ s/\&gt/ /g; 
$plainrow =~ s/\&#91/ /g;  
$plainrow =~ s/\&#93/ /g; 
$plainrow =~ s/[\.\,\:\;\!\?\-\(\)\+\=\@\$\%\^\&\*\_\~\`\{\}\[\]\|\"\'\<\>\\\/0123456789´‘’®©™“”²…«»]/ /g;
$plainrow =~ s/\s+/ /g; # reduce series of spaces to a single space
$plainrow =~ s/^\s//; # remove leading space
$plainrow =~ s/\s$//;  # remove trailing space
print $plainrow."\n"; 

$_ = $plainrow;
my @words = split/\s/, $plainrow;
# record new words
foreach $word (@words) {
###
my $wl = length($word);
#print "word $word has length $wl\n"; 
if ($wl>3) {

$wordcount++; 
print "\n>>$word<<?  "; 

if (!$speller->check($word)) {
$badcount++;
print "$word | "; 
} # end if

} # end if word is of length 4 or greater
###
} # end for each word on list



my $goodcount = $wordcount - $badcount; 
print "\ngoodcount $goodcount, "; 
my $goodProportion = 1;   # default: keep the line
if ($wordcount>0) {
	$goodProportion = $goodcount/$wordcount; 
	print "goodProportion $goodProportion\n"; 
}
if ($goodProportion>=$thresh) {
	print EGOODLINES $erow."\n";; 
	print EBADLINES "\n"; 
	print RGOODLINES $rrow."\n";; 
	print RBADLINES "\n"; 
} else {
	print "\nbadline: $erow\n"; 
	print EGOODLINES "\n";   # keep a blank line
	print EBADLINES $erow."\n";; 
	print RGOODLINES "\n";
	print RBADLINES $rrow."\n";
} # end if else enough good words in the line


} else {
	# English row is blank, exclude line from both files
	print EGOODLINES "\n";   
	print EBADLINES $erow."\n";
	print RGOODLINES "\n";
	print RBADLINES $rrow."\n";
} # end if else not blank row

} # end while reading infile

close INEN;
close INRU;
close EGOODLINES;
close EBADLINES;
close RGOODLINES;
close RBADLINES;  

sub removePunctuation() {
	my $word = shift;
	my $newword = $word;
	print "new word $newword\n"; 
	$newword =~ s/\.//g;
	$newword =~ s/\,//g;
		print "new word $newword\n"; 
	$newword;
} # end removePunctuation


