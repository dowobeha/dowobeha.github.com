import java.io.*;
import java.util.*;
import java.util.StringTokenizer;
import java.util.HashMap;

// reverse each letter in a line (to fix pdf extraction problems)
// this version outputs to the local directory
//TODO:  make this an argument
//String folder = "/home/youngkm/kjava/com/nspaceanalysis/utilities/dari-pashto/pdf-dari-reversals/";


public class KCharacterReverseLocal{
    // variables go here
    public HashMap ctrans = new HashMap();
// methods of class KCharacterReverseLocal go here
public String reverseWords(String in) {
String ret = in;
//System.out.println("input >>" + in + "<<");
StringBuffer inbuff = new StringBuffer(in);
StringBuffer outbuff = new StringBuffer();

/*
StringTokenizer st = new StringTokenizer(in); // split on spaces
String temp = new String();
while (st.hasMoreTokens()) {
temp = st.nextToken();
outbuff.insert(0, temp + " ");
} // end while
*/

//for (int i =0; i < inbuff.length()-1; i++) {
for (int i =0; i < inbuff.length(); i++) {
char nextchar = inbuff.charAt(i);
outbuff.insert(0, nextchar);
} // end for buffer length



ret = outbuff.toString();
ret = ret.trim();
//System.out.println("reversed >>" + ret + "<<");
return ret;
} // end reverseWords






    public void reverseLines(String f, String outputf) throws UnsupportedEncodingException, IOException{
    try {
        BufferedReader in = new BufferedReader(
           new InputStreamReader(new FileInputStream(f), "UTF8"));
	Writer out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outputf), "UTF8"));

	// read a line into variable temp, if not null, add to string buffer
StringBuffer tempBuff = new StringBuffer();
String temp = new String();
	while ( (temp=in.readLine()) != null) {
//tempBuff.append("ORIGINAL: " + temp + "\n");
//String trans = transliterate(temp);
//tempBuff.append("TRANLIT: " + trans + "\n");
String pmet = reverseWords(temp);
//tempBuff.append(pmet + "\n\n");
tempBuff.append(pmet + "\n");
} // end if not blank line
String tempAll = tempBuff.toString();
//System.out.println(tempAll);
out.write(tempAll);
		in.close();
	out.close();
    } catch (UnsupportedEncodingException e) {
System.out.println("problem with encoding");
System.out.println(e.getMessage());
    } catch (IOException e) {
System.out.println("io exception");
System.out.println(e.getMessage());
    }
    } // end  reverseLines

// remove extension if present
public String removeExtension(String f) {
String out = new String(f);
String ext = new String();
int dotspot = f.lastIndexOf('.');
if (dotspot>0) {
ext = f.substring(dotspot);
out = f.substring(0, dotspot);
}
return out;
} // end removeExtension

    //-----------------------------
    // constructor for KCharacterReverseLocal
    public KCharacterReverseLocal () {

    } // end constructor
	      
    //----------------------------

    public static void main (String[] args) throws UnsupportedEncodingException, IOException {
if (args.length!=2) {
System.err.println("Usage:  java KCharacterReverseLocal <filename> <destination-folder>");
System.exit(0);
} // end if check arguments
String inputstring = args[0];
	KCharacterReverseLocal c = new KCharacterReverseLocal();
String localfolder = args[1];	
	
File f = new File(inputstring);
String local = f.getName();

//TODO:  make this an argument
String folder = "/home/youngkm/kjava/com/nspaceanalysis/utilities/dari-pashto/" + localfolder + "/";	
String outputstring = folder + local + "-reversed.txt";
c.reverseLines(inputstring, outputstring);
System.out.println("character-reversed lines output to " + outputstring);
    } // end main
} // end class KCharacterReverseLocal




