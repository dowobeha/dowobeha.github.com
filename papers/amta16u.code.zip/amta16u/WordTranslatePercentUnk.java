import java.io.*;
import java.util.*;
import java.util.StringTokenizer;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

	// NOTE: this will fail if lexicon has entries with no gloss
	// can fix lexicon by adding null glosses

// this version gives a percent unknown for the specified file and dictionary
// used to find Dari and Pashto reversed files 
// take baseline percent unk for good files (v9)
// look at pdf-articles files, any that have a higher than normal percent unk
//   might be wrong language, pdf-reversal, or other problem

// outputs to local (utilities) directory
// suppress translation output, just interested in count of unknown words
// calculate percent unk:  unk words/total words

// usage notes for WordTranslate program:  
// utility to provide a rough, dictionary based translation of Urdu sentences
// two options
// simple translation provides a scorable line for line translation
// detailed translation is used to examine alignment problems
// simple translation returns line for line translation, based on looking up words and phrases in the LCTL lexicon, checking phrases up to three words long
// prefixes (JANG_URD_12345 etc.) are echoed but not translated
// detailed translation repeats input and reference translation if present, adds word translation, and also adds transliteration of the line
// both versions create a file of unknown words, for off-line translation
// both versions include a list of translations for unknown words and exceptions
// allowing us to fine-tune the translations provided by the LCTL lexicon

public class WordTranslatePercentUnk{
    // variables go here
// default is simple translation, may be set to detailed in command line with optional argument "d"
public boolean detail = false;
public boolean tranlistonly = false;
// keep track of unknowns at top level
//KLM public StringBuffer unknowns = new StringBuffer("");
//KLM public StringBuffer unknowns2 = new StringBuffer("");
// track line number for recording unknowns
public int line = 0;
    public HashMap ctrans = new HashMap();
	private Hashtable<String, LexEntry2> lexMap;
    // add table to override translations of postpositions
    public HashMap exceptions = new HashMap();

    //use this stuff to normalize the POS tag labels
    private static Hashtable<String, String> posLabelMap;	
    //table of postposition words to help construct NP's and chunk things.
    private static Hashtable<String, String> postPosTable;
    static {

	postPosTable = new Hashtable<String, String>();
	postPosTable.put("\u0646\u06D2", "ne");  //ergative
	postPosTable.put("\u06A9\u0648", "ko");  //accusative/dative
	postPosTable.put("\u0633\u06D2", "se");  //instrumental
	postPosTable.put("\u06A9\u06D2", "ke");  //genitive (m. pl.)
	postPosTable.put("\u06A9\u0627", "ka");  //genitive (m. sg.)
	postPosTable.put("\u06A9\u06CC", "ki");  //genitive (fem.)
	postPosTable.put("\u067E\u0631", "par"); //locative: on, at
	postPosTable.put("\u062A\u06A9", "tak"); //locative: until
	postPosTable.put("\u0645\u064A\u06BA", "meyn"); //locative: in
    }


 

    private class LexEntry2 {
	public Vector<String> trans;

	public LexEntry2 (Vector<String> t) {
	    init();
	    trans = t;
	}

	private void init() {
	    trans = new Vector<String>();
	}
    }
    // ---------------------------------------------------
    // methods of class WordTranslatePercentUnk go here

    private void init() {
	lexMap = new Hashtable<String, LexEntry2>();
    }


    public boolean loadLexMap2(String lexFileName) {
	boolean ret = true;
	Document document = null;
	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	DocumentBuilder builder = null;
	try {
	    builder = factory.newDocumentBuilder();
	} catch (ParserConfigurationException e) {
	    System.out.println("Parser config error: " + e.getMessage());
	    e.printStackTrace();
	}
	try {
	    document = builder.parse(lexFileName);
	} catch (SAXException e) {
	    System.out.println("SAX Parser exception: " + e.getMessage());
	    e.printStackTrace();
	} catch (IOException e) {
	    System.out.println("IO Exception: " + e.getMessage());
	    e.printStackTrace();
	}

	NodeList domNodeList = document.getElementsByTagName("ENTRY");
	for(int i=0; i < domNodeList.getLength(); i++) {
	    String word = null;
	    String trans = null;
	    Vector<String>transvector = new Vector<String>();;
	    NodeList children = domNodeList.item(i).getChildNodes();
	    for(int j=0; j < children.getLength(); j++) {
		String cname = children.item(j).getNodeName();
		if(cname == "WORD") {
		    word = children.item(j).getTextContent();
		} 
				
		// add multiple translations from each line to the translation vector
		// accumulate translations from multiple gloss lines 
		else if(cname == "GLOSS") {
		    trans = children.item(j).getTextContent();
		    String chunks[] = trans.split(",");
		    // can take first entry: [0] or last entry: [chunks.length-1]
		    if (chunks.length>0) {
			for (String temp : chunks) {
			    transvector.add(temp);
			}
		    }
		}
		if(word != null) {
		    lexMap.put(word, new LexEntry2(transvector));
		}
	    }
	}
//	System.out.println("LexMap contains " + lexMap.size() + " entries");
	return ret;
    }

	public void percentunknown (String f, String un) throws UnsupportedEncodingException, IOException{
//	    System.out.println("reading encoding UTF8, writing encoding UTF8");
		String temp = new String("");

		    try {
			BufferedReader in = new BufferedReader(
	   //           new InputStreamReader(new FileInputStream(f), "UTF8"));
	   //	Writer out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outputf), "UTF8"));
           new InputStreamReader(new FileInputStream(f), "UTF8"));
//			    Writer outun= new BufferedWriter(new OutputStreamWriter(new FileOutputStream(un), "UTF8"));

int unkcount = 0;
int totalwords = 0;
double percent = 0;
int unknowncount = 0;
				// read a line into variable temp, if not null, process it
				while ( (temp=in.readLine()) != null) {
line++;  // line counter for recording unknown words
				    if (temp.length()>0) {
					//  echo, do not process, prefix "bla-bla-bla123\\"
					String sub = temp;  // if no prefix, sub = entire line
					String prefix = "";
					if (temp.contains("\\\\")) {
					    int slashloc = temp.indexOf("\\");
					    sub = temp.substring(slashloc+2);
					    prefix = temp.substring(0, slashloc+2);
					}
					StringBuffer tempbuff = new StringBuffer(sub);
					StringBuffer outputwords = new StringBuffer("");
					StringBuffer outputcharacters = new StringBuffer("");
					// for phrase translation
					StringBuffer phrasewords = new StringBuffer("");
					Vector<String> normwords = new Vector<String>();

					// normalize spelling
					//sub = spell(sub);

					// read a word
					// find that word in lctl lexicon
					// return first translation from lexicon
					//TODO add aditional punctuation to list
					//can't include \u0022 = "  , use \" instead
					StringTokenizer st = new StringTokenizer(sub, "\u2018\u2019\u201C\u201D\u2026\u02DC\u0060\u005F\u007C\u002D\u0027\u2014\u008D\u002B\u0021\u003F\u06D4\u060C\u061B\u061F\u003A\" ,.'\\'");
					while (st.hasMoreTokens()) {
					    String word = st.nextToken();
					totalwords++;
					    // collect normalized words for possible phrase translations
					    normwords.add(word);
					} // end tokenization

					//start with word a, try phrase abc, then ab, then a
					// next un-translated word becomes new a
					int i = 0;
					while(i<normwords.size()-2) {
					    String a = (String)normwords.get(i);
					    String b = (String)normwords.get(i+1);
					    String c = (String)normwords.get(i+2);
					    String abc = a + " " + b + " " + c;
					    String ab = a + " " + b;
// first screen out non-Arabic characters
boolean anon = false;
boolean bnon = false;
boolean cnon = false;
// first check for non-Arabic characters, pass them through unchanged
//TODO what about words with mixed lettering?  

// check first character
char achar = a.charAt(0);
// if out of Arabic character range
if ((achar<'\u0600') || (achar>'\u06FF')){
anon = true;
//System.out.println("non Urdu character " + achar + " in " + a);
} // end if out of range

					    String abctrans = trans(abc);
					    String abtrans = trans(ab);
					    String atrans = trans(a);
					    // look for abc
					    // if found, i = i+3
//System.out.println("looking for " + abc);
					    if (!abctrans.equals("UNK")) {
//System.out.println("translated phrase " + abc + " as " + abctrans);
						outputwords.append(abctrans + " ");
						i = i+ 3;
					    } else if (!abtrans.equals("UNK")) {    // look for ab; if found, i= i+2
//System.out.println("translated phrase " + ab + " as " + abtrans);
						outputwords.append(abtrans + " ");
						i = i+ 2;
					    } else  {
// if anon, pass through unchanged, and increment index
if (anon) {
atrans = a;
outputwords.append(atrans+ " ");
i = i+1;
} else {
	// look for a; if not found, use UNK; in any event, i = i+1
//System.out.println("word level translation for " + a + " is " + atrans);
//System.out.println("found " + a + " " + atrans + " " + transliterate(a));
						outputwords.append(atrans + " ");
// record unknown single word, with its transliteration
if (atrans.equals("UNK")) {
//unknowns.append(line + " " + a+ " [" + transliterate(a) + "]\n");
//unknowns.append(a + " " +transliterate(a) + "\n");
//KLM unknowns.append(a + "\n");
unkcount++;
} 

// check for words with "unknown" as gloss (many of these were added to Humayoun lexicon)

if (atrans.equals("unknown")) {
unknowncount++;
System.out.println("found but no gloss: " + a);
} 

						i = i+1;
} // end if else a= nonUrdu 
					    } // end third else clause
//System.out.println("index becomes " + i);

					} // end while can find three words

					// if two words left
					if (i<normwords.size()-1) {
//System.out.println("two words left");
					    String y = (String)normwords.get(i);
					    String z = (String)normwords.get(i+1);
// check for nonUrdu words
boolean ynon = false;
// check first character
char ychar = y.charAt(0);
// if out of Arabic character range
if ((ychar<'\u0600') || (ychar>'\u06FF')){
ynon = true;
//System.out.println("non Urdu character " + ychar + " in " + y);
} // end if out of range
boolean znon = false;
// check first character
char zchar = z.charAt(0);
// if out of Arabic character range
if ((zchar<'\u0600') || (zchar>'\u06FF')){
znon = true;
//System.out.println("non Urdu character " + zchar + " in " + z);
} // end if out of range
					    // look for yz
					    String yz = y + " " + z;
					    String yztrans = trans(yz);
//System.out.println("looking for " + yz);
					    // if not found, look for y and z independently
					    if (!yztrans.equals("UNK")) {
//System.out.println("translated phrase " + yz + " as " + yztrans);
						outputwords.append(yztrans + " ");
						i = i+2;
//System.out.println("index becomes " + i + ", out of possible " + normwords.size());
					    } else {
// if ynon, pass through unchanged, and increment index
						String ytrans = trans(y);
						String ztrans = trans(z);
if (ynon) {
ytrans = y;
outputwords.append(ytrans+ " ");

} else {
//System.out.println("found " + y + " " + ytrans  + " " + transliterate(y));
						outputwords.append(ytrans + " ");
// record unknown single word, with its transliteration
if (ytrans.equals("UNK")) {
//unknowns.append(line + " " + y+ " [" + transliterate(y) + "]\n");
// KLM unknowns.append(y + " " +transliterate(y) + "\n");
}
} // end if else ynon
if (znon) {
ztrans = z;
outputwords.append(ztrans+ " ");

} else {
//System.out.println("found " + z + " " + ztrans  + " " + transliterate(z));
						outputwords.append(ztrans + " ");
if (ztrans.equals("UNK")) {
//unknowns.append(line + " " + z+ " [" + transliterate(z) + "]\n");
// KLM unknowns.append(z + " " +transliterate(z) + "\n");
} 
} // end if else znon

//System.out.println("translating " + y + " as " + ytrans);
//System.out.println("translating " + z + " as " + ztrans);
					    } // end y, z independently
					} else if (i<normwords.size()) {
//System.out.println("index is " + i + ", out of possible " + normwords.size() + "; 1 word left");
					    // if one word left

					    String z = (String)normwords.get(i);
					    // look for z, or use UNK
					    String ztrans = trans(z);
//System.out.println("one word left " + z + " " + transliterate(z) + " " + ztrans);
boolean znon = false;
// check first character
char zchar = z.charAt(0);
// if out of Arabic character range
if ((zchar<'\u0600') || (zchar>'\u06FF')){
znon = true;
//System.out.println("non Urdu character " + zchar + " in " + z);
} // end if out of range
if (znon) {
ztrans = z;
outputwords.append(ztrans+ " ");

} else {
						outputwords.append(ztrans + " ");
if (ztrans.equals("UNK")) {
//** omit line numbers, so we can find unique entries
//unknowns.append(line + " " + z+ " [" + transliterate(z) + "]\n");
// KLM unknowns.append(z + " " +transliterate(z) + "\n");
} 
} // end if else znon

					    
//System.out.println("translating final word " + z + " as " + ztrans);
					} 
					//------------------------------
					// transliterate entire line
					String translit = transliterate(sub);
					outputcharacters.append(translit);
					//------------------------------
					//outputwords.append("\n");
					//outputcharacters.append("\n");
					String outwords = outputwords.toString();
					String outchars = outputcharacters.toString();



			}	 // end if not blank line
		    } // end while line is not null
// output unknowns 
// KLM String unknownsString = unknowns.toString();
// KLM outun.write(unknownsString);

double unkdouble = unkcount + 0.0;
percent = unkdouble/totalwords;
percent = percent * 100;

// for lexicon check
//System.out.println("  " + unkcount + " words not found in dictionary ");
//System.out.println("  " + unknowncount + " words found but no gloss ");
//System.out.println("  " + totalwords + " total words");


System.out.print(Math.round(percent) + " % unknown words in ");

in.close();
// KLM outun.close();

			      } catch (UnsupportedEncodingException e) {
	    System.out.println("problem with encoding");
	    System.out.println(e.getMessage());
		} catch (IOException e) {
	    System.out.println("io exception");
	    System.out.println(e.getMessage());
		}
} // end  translate

/*
boolean nonUrdu = false;
// first check for non-Arabic characters, pass them through unchanged
//TODO what about words with mixed lettering?  
StringBuffer buff = new StringBuffer(in);
// check first character
char c = buff.charAt(0);
// if out of Arabic character range
if ((c<'\u0600') || (c>'\u06FF')){
nonUrdu = true;
System.out.println("non Urdu character " + c + " in " + in);
} // end if out of range

if (nonUrdu) {
ret = in;  // don't translate
}  else {
*/

//string translation, input may be a single word or a phrase
public String trans(String in) {
    String ret = "---";  
    // first check exceptions, then check lexicon
    String mappedTrans = (String)exceptions.get(in);
    if (mappedTrans!=null) {
//System.out.println("found on exceptions list:  " + in + " " + mappedTrans);
	ret = mappedTrans;
    } else {
	LexEntry2 m = lexMap.get(in);
	//TODO  pick most frequent English word here?
	// NOTE: this will fail if lexicon has entries with no gloss
	// can fix lexicon by adding null glosses
	// debug System.out.println(">> " + in);
	if ((m!=null)&&(m.trans!=null)) {
	    String best = m.trans.get(0); // default to first entry
	    int bestscore = 0; // replace 0 with frequency score for first entry
	    for (String temp: m.trans) {
		//System.out.println("temp is " + temp);
		// get frequency score for temp
		// if temp.score>best.score,  best = temp

	    } // end for
//System.out.println("found in lexicon " + in + " " + best);
	    ret = best;
	} else {
	    // if not found, return UNK
	    ret = "UNK";
	} 
    } // end if else exception

    return ret;
} // end trans

/*
//normalize spelling
// [i] with two dots becomes [i[
// Arabic [k] becomes [k]
//[|~] sequence becomes single character
public String spell(String in) {
    String ret = in;
    StringBuffer buff = new StringBuffer();
    for (int i=0; i<in.length(); i++) {
	char c = in.charAt(i);
	String cs = c + ""; 
	// first, convert double character combinations
// alif maad 
// single:  0622 :    آ     
// double:  0627 |, 0653 ~ :    آ   
if ((cs.equals("\u0627"))&&(i+1<in.length())) {
//found alif and not final
i++;
char cnext = in.charAt(i);
String csnext = cnext + "";
if (csnext.equals("\u0653")) { 
//found ~ after alif
// convert sequence |~ to single character
cs = "\u0622";
System.out.println("normalized alif mad " + in);
} else {
// keep alif, and process this character normally
buff.append("\u0627");  // |
cs = csnext;  
} // end if else |~
} // end found |

// convert single characters
if (cs.equals("\u0643")) {
	    cs = "\u06A9";
	System.out.println("normalized k " + in);
	} else if (cs.equals("\u064A")) {
	    cs = "\u06CC";
System.out.println("normalized i " + in);
// consider mapping 0670 to 0627 -- superscript alef to alif
//	} else if (cs.equals("\u0670")) {
//	   cs = "\u0627";

} // end if else

// remove diacritics  -- 0650 i e.g.
// 0640 064f 0650 0651 0670
if ( (cs.equals("\u0650"))||(cs.equals("\u0651"))||(cs.equals("\u0670"))||(cs.equals("\u0640"))||(cs.equals("\u064F"))  ){
System.out.println("removed diacritics-- " + cs + " " + in);
cs = "";
} 

// remove diacritics  FE76-FE7F
if ( (cs.equals("\uFE76"))||(cs.equals("\uFE77"))||(cs.equals("\uFE78"))||(cs.equals("\uFE79"))||(cs.equals("\uFE7A"))||(cs.equals("\uFE7B"))||(cs.equals("\uFE7C"))||(cs.equals("\uFE7D"))||(cs.equals("\uFE7E"))||(cs.equals("\uFE7F")) ) {
System.out.println("removed diacritics: " + cs + " " + in);
cs = "";
}


	buff.append(cs);
    } // end for char in word
    ret = buff.toString();
    return ret;
} // end spell
*/

//transliterate:  letter for letter 
public String transliterate(String in) {
    String ret = in;
    StringBuffer buff = new StringBuffer();
    for (int i=0; i<in.length(); i++) {
	char c = in.charAt(i);
	String cs = c + ""; 
	String newc = new String();
	newc = (String)ctrans.get(cs);
	if (newc==null) {
	    newc = cs;
	} // end if
	buff.append(newc);
    } // end for char in word
    ret = buff.toString();
    return ret;
} // end transliterate

//TODO  consider for detailed translation option
public void initMapDetailed() {
    ctrans.put("\u0628", "b");
    ctrans.put("\u067E", "p");
    ctrans.put("\u062A", "t");
    ctrans.put("\u0679", "t.");  // retroflex tb
    ctrans.put("\u062B", "s.");  // from Arabic theta
    ctrans.put("\u062C", "j");  // affricate dz,
    ctrans.put("\u0686", "ch");  // affricate
    ctrans.put("\u062D", "h"); // [h] or final short vowel
    ctrans.put("\u062E", "x");
    ctrans.put("\u062F", "d");
    ctrans.put("\u0688", "d.");  // retroflex db
    ctrans.put("\u0630", "z");
    ctrans.put("\u0631", "r");
    ctrans.put("\u0691", "r.");  // retroflex rb
    ctrans.put("\u0632", "z."); // from Arabic thorn
    ctrans.put("\u0698", "zh");  // fricative
    ctrans.put("\u0633", "s"); 
    ctrans.put("\u0634", "sh"); // fricative
    ctrans.put("\u0635", "s."); // from Arabic emphatic s.
    ctrans.put("\u0636", "z."); // from Arabic emphatic d.
    ctrans.put("\u0637", "t."); // retroflex, from Arabic emphatic t
    ctrans.put("\u0638", "z.");  // from Arabic emphatic thorn
    ctrans.put("\u0639", "a.");  // ain [?] or [a]
    ctrans.put("\u063A", "gh"); // voiced velar fricative
    ctrans.put("\u0641", "f");
    ctrans.put("\u0642", "q");
    ctrans.put("\u06A9", "k");
    ctrans.put("\u06AF", "g");
    ctrans.put("\u0644", "l");
    ctrans.put("\u0645", "m");
    ctrans.put("\u0646", "n");
    ctrans.put("\u06BE", "H"); //aspiration
    ctrans.put("\u06BA", "~");  //nasalization
    ctrans.put("\u0621", "^");  // hamzaa  [?] or silent
    ctrans.put("\u06C1", "h.");  // ہ choti-he [a] finally, [h] otherwise
    ctrans.put("\u0648", "o");  // [o], [u], [C], or [w]
    ctrans.put("\u06CC", "y"); // [y], [i], or medial [e], [ae]
    ctrans.put("\u06D2", "e");  // [e], [ae]
    ctrans.put("\u0622", "a:");
    ctrans.put("\u0627", "a");  // intially, [schwa], [I], [U]; medially [a:]

    ctrans.put("\u0626", "i^"); // ئ hamzaa over i
    ctrans.put("\u0624", "o^"); //  ؤ hamzaa over o
    ctrans.put("\u064F", "^"); // hamzaa over |

    // special characters found in r116 training data, but not in LCTL lexicon
    //TODO map these to corresponding characters (but leave 0647, found in names)
    ctrans.put("\u0643", "-k-"); // ك Arabic [k] symbol
    ctrans.put("\u064A", "-y:-"); // ي isolated or final form of [i] with diacritic dots (2 dots below)
    ctrans.put("\u0647", "-h-"); // ه Arabic [h] symbol, found in LCTL lexicon only in Allah etc.  عبدالله الحمدلله  الله

    // 0647 found in LCTL lexicon in Allah, 'grace', 'hallelujah'   الحمدلله الحمدالله  الله  
    // 0647 found in r116 in names:  Allah الله Abdullah عبدالله  Ubaid Ullah عبیدالله 
    // and once in JANG_URD_20060331.81501-5  هے  [he] 'be'? may be a typo  
    // 0647 is substituted for 06C1 in some other sources (e.g., list of most frequent Urdu words)

    // other special characters
    ctrans.put("\u0649", "-y-"); // looks like 06CC -- not used in r116 training data or in LCTL lexicon

    // note that gedit search function considers 064A  = 0626   ئ = ي
    // searching for 064A w/two dots returns both; searching for 0626 w/hamzaa only gets 0626 -- ?!

} // end initMapDetailed

// transliteration simplified here because non-letters were being reversed left-to-right in the list of unknowns
public void initMap() {
ctrans.put("\u0628", "b");
ctrans.put("\u067E", "p");
ctrans.put("\u062A", "t");
ctrans.put("\u0679", "t");  // retroflex tb
ctrans.put("\u062B", "s");  // from Arabic theta
ctrans.put("\u062C", "j");  // affricate dz,
ctrans.put("\u0686", "ch");  // affricate
ctrans.put("\u062D", "h"); // [h] or final short vowel
ctrans.put("\u062E", "x");
ctrans.put("\u062F", "d");
ctrans.put("\u0688", "d");  // retroflex db
ctrans.put("\u0630", "z");
ctrans.put("\u0631", "r");
ctrans.put("\u0691", "r");  // retroflex rb
ctrans.put("\u0632", "z"); // from Arabic thorn
ctrans.put("\u0698", "zh");  // fricative
ctrans.put("\u0633", "s"); 
ctrans.put("\u0634", "sh"); // fricative
ctrans.put("\u0635", "s"); // from Arabic emphatic s.
ctrans.put("\u0636", "z"); // from Arabic emphatic d.
ctrans.put("\u0637", "t"); // retroflex, from Arabic emphatic t
ctrans.put("\u0638", "z");  // from Arabic emphatic thorn
ctrans.put("\u0639", "a");  // ain [?] or [a]
ctrans.put("\u063A", "gh"); // voiced velar fricative
ctrans.put("\u0641", "f");
ctrans.put("\u0642", "q");
ctrans.put("\u06A9", "k");
ctrans.put("\u06AF", "g");
ctrans.put("\u0644", "l");
ctrans.put("\u0645", "m");
ctrans.put("\u0646", "n");
ctrans.put("\u06BE", "H"); //aspiration
ctrans.put("\u06BA", "N");  //nasalization  note: left-right problems if we just write ~
ctrans.put("\u0621", "Z");  // hamzaa  [?] or silent
ctrans.put("\u06C1", "h");  // ہ choti-he [a] finally, [h] otherwise
ctrans.put("\u0648", "o");  // [o], [u], [C], or [w]
ctrans.put("\u06CC", "y"); // [y], [i], or medial [e], [ae]
ctrans.put("\u06D2", "e");  // [e], [ae]
ctrans.put("\u0622", "A");
ctrans.put("\u0627", "a");  // intially, [schwa], [I], [U]; medially [a:]

ctrans.put("\u0626", "i"); // ئ hamzaa over i
ctrans.put("\u0624", "o"); //  ؤ hamzaa over o
ctrans.put("\u064F", "A"); // hamzaa over |

// special characters found in r116 training data, but not in LCTL lexicon
//TODO map these to corresponding characters (but leave 0647, found in names)
ctrans.put("\u0643", "k"); // ك Arabic [k] symbol
ctrans.put("\u064A", "y"); // ي isolated or final form of [i] with diacritic dots (2 dots below)
ctrans.put("\u0647", "h"); // ه Arabic [h] symbol, found in LCTL lexicon only in Allah etc.  عبدالله الحمدلله  الله

// 0647 found in LCTL lexicon in Allah, 'grace', 'hallelujah'   الحمدلله الحمدالله  الله  
// 0647 found in r116 in names:  Allah الله Abdullah عبدالله  Ubaid Ullah عبیدالله 
// and once in JANG_URD_20060331.81501-5  هے  [he] 'be'? may be a typo  
// 0647 is substituted for 06C1 in some other sources (e.g., list of most frequent Urdu words)

// other special characters
ctrans.put("\u0649", "y"); // looks like 06CC -- not used in r116 training data or in LCTL lexicon

// note that gedit search function considers 064A  = 0626   ئ = ي
// searching for 064A w/two dots returns both; searching for 0626 w/hamzaa only gets 0626 -- ?!

} // end initMap

public void initExceptions() {
//detailed translation option
    // postpositions
if (detail) {
    exceptions.put("\u0646\u06D2", "ERG");  //ergative
    exceptions.put("\u06A9\u0648", "ACC/DAT");  //accusative/dative
    exceptions.put("\u0633\u06D2", "INS");  //instrumental
    exceptions.put("\u06A9\u06D2", "GEN");  //genitive (m. pl.)
    exceptions.put("\u06A9\u0627", "GEN");  //genitive (m. sg.)
    exceptions.put("\u06A9\u06CC", "GEN");  //genitive (fem.)      // ka?
    exceptions.put("\u067E\u0631", "LOC:on,at"); //locative: on, at
    exceptions.put("\u062A\u06A9", "LOC:until"); //locative: until
    exceptions.put("\u0645\u06CC\u06BA", "LOC:in"); //locative: in
} else {
// postpositions:  need word-for-word translations for scoring translations
		exceptions.put("\u0646\u06D2", "by");  //ergative
		exceptions.put("\u06A9\u0648", "to");  //accusative/dative
		exceptions.put("\u0633\u06D2", "with");  //instrumental
		exceptions.put("\u06A9\u06D2", "of");  //genitive (m. pl.)
		exceptions.put("\u06A9\u0627", "of");  //genitive (m. sg.)
		exceptions.put("\u06A9\u06CC", "of");  //genitive (fem.)
		exceptions.put("\u067E\u0631", "at"); //locative: on, at
		exceptions.put("\u062A\u06A9", "until"); //locative: until
		exceptions.put("\u0645\u06CC\u06BA", "in"); //locative: in ; also "I"
} // end detail option vs. translation option for postpositions

    // first person pronoun + ergative postposition
    exceptions.put("\u0645\u06CC\u06BA \u0646\u06D2", "I");   // myn ne
    // additions

/*
    //TODO can't handle phrases; using work-arounds:
    exceptions.put("بین", "inter-");  // international news = "bean" + "the national" + "news"
    exceptions.put("بین الاقوامی", "international news");

//TODO is this backwards or forwards?  written like this in the LCTL lexicon
    exceptions.put("کام ڈاٹ", "dot com"); // dot com
// written like this in the training data--this one works
	exceptions.put("ڈاٹ کام", "dot.com"); // dot com

    exceptions.put("وکٹ", "wicket"); 
    exceptions.put("کراچی", "Karachi");
    exceptions.put("کھیلوں", "sports");
    exceptions.put("نیوز", "news");
    exceptions.put("قومی", "national");
    exceptions.put("خبریں", "news");
    exceptions.put("خبر", "news");
    exceptions.put("نیوزڈیسک", "newsdesk");
    exceptions.put("رپورٹ", "report");
    exceptions.put("رپورٹر", "reporter");
    exceptions.put("اسٹاف", "staff");
    exceptions.put("مہر", "Mehr");
    exceptions.put("جنگ", "Jang");
    exceptions.put("بی بی سی", "BBC");
    exceptions.put("نامہ نگار", "correspondent");
    exceptions.put("نمائندہ", "correspondent");
    exceptions.put("ریڈیو", "radio");
    exceptions.put("پریس", "press");
    exceptions.put("ايجنسي", "agency");
    exceptions.put("ڈاٹ کام", "dot com");
    exceptions.put("رساں", "carrier");

    // means riddle or first, first is more likely so force it here
    exceptions.put("پہلی", "first");

// *** exceptions added after processing u-test.snt ***
exceptions.put("کرنے", "do");
*/
}

public String readCharFileToString(String f) {
    String temp = new String("");
	try {
	    BufferedReader in = new BufferedReader(
            new InputStreamReader(new FileInputStream(f), "UTF8"));
		String str = in.readLine();
		    temp = str;
			} catch (UnsupportedEncodingException e) {
	} catch (IOException e) {
	}
	    return temp;
		} // end  readCharFileToString

public void writeCharFile(String filename, String output) {
    try {
        Writer out = new BufferedWriter(new OutputStreamWriter(
            new FileOutputStream(filename), "UTF8"));
	    out.write(output);
		out.close();
		    } catch (UnsupportedEncodingException e) {
    } catch (IOException e) {
    }
	} // end writeCharFile

// remove extension if present
public String removeExtension(String f) {
    String out = new String(f);
    String ext = new String();

    int dotspot = f.lastIndexOf('.');
    if (dotspot>0) {
	ext = f.substring(dotspot);
	out = f.substring(0, dotspot);
    }
    return out;
} // end removeExtension

// get last name in pathname
public String getFileName(String f) {
    String out = new String(f);
    String filename = new String();

    int slashspot = f.lastIndexOf('/');
    if (slashspot>0) {
	filename = f.substring(slashspot+1);
//System.out.println("dictionary filename is " + filename);
	out = filename;
    }
    return out;
} // end removeExtension
//-----------------------------
// constructor for WordTranslatePercentUnk
public WordTranslatePercentUnk() {
    //initiation code goes here

} // end constructor

//----------------------------

public static void main (String[] args) throws UnsupportedEncodingException, IOException {
    if ((args.length>2) || (args.length<1)){
	System.err.println("Usage:  java -server -mx2g WordTranslatePercentUnk <filename> <dictionary>");
System.err.println("for Dari:  farsi-prelim-k.llf.xml");
//System.err.println("NE dictionary:  /data/LCTL/LCTL_Urdu_v1.0/Lexicon/mt08-urdu-NE.llf.xml");
	System.exit(0);
    } // end if check arguments
String dictionarySelection = args[1];

    String inputstring = args[0];

    WordTranslatePercentUnk c = new WordTranslatePercentUnk();

String dictionaryName = c.getFileName(dictionarySelection);
String local = "/home/youngkm/kjava/com/nspaceanalysis/utilities/";


//File f = new File(inUrdu);
//String local = f.getName();
//String outUrdu = "/home/youngkm/kjava/com/nspaceanalysis/utilities/" + local;

String inputname = c.getFileName(inputstring);
String outputstring = local + inputname + "-" + dictionaryName + "-list.txt";
 //   c.initMap();
    c.init();

c.loadLexMap2(dictionarySelection);
    c.percentunknown(inputstring,outputstring);
    System.out.println("file " + inputname + " via lexicon " + dictionaryName);
//System.out.println("unknown words written to " + outputstring);

    
	} // end main
} // end class WordTranslatePercentUnk




