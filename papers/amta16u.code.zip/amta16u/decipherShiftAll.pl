#!/usr/bin/perl
#
#  apply shift delta deciphering on all text (used for debugging)


use strict;
use Getopt::Std;

binmode(STDOUT, ":utf8");

our($opt_i, $opt_o, $opt_d);
getopts("i:o:d:");

if(!$opt_i) {
    die "No input file specified with -i!\n";
}

if(!$opt_o) {
    die "No output file specified with -o!\n";
}
if(!$opt_d) {
    die "No shift factor delta specified with -d!\n";
}

open (INFILE, $opt_i) or die "$0: Unable to open input file: $opt_i\n";
open (OUTFILE, ">$opt_o") or die "$0: Unable to open output file: $opt_o\n";

binmode(INFILE, ":utf8");
binmode(OUTFILE, ":utf8");

print "infile:  $opt_i\n";
print "deciphered all characters (use for debugging only): $opt_o\n";

my $delta = $opt_d; 

while(my $row = <INFILE>) {
my $shiftedrow = ""; 
my @cs = split //, $row;
for (my $i=0; $i<@cs; $i++) {
	my $ci = $cs[$i];

#####	if (shifted848($ci)) {
		my $newi = shiftDelta($ci); 
		$shiftedrow= $shiftedrow.$newi;
#####	} else {
#####		$shiftedrow = $shiftedrow.$ci;
#####	} # end if else shifted candidate
	
}# end for chars in row
print OUTFILE $shiftedrow."\n";
print  "$shiftedrow\n";
} # end while input 
close INFILE;
close OUTFILE;



# TODO -- split Number set into "English" vs. "Arabic" vs. "Chinese" etc.

	



# get codepoint
# change codepoint by delta
# generate character for new codepoint
sub shiftDelta() {
my $char = shift;
#print "in deltaF2C with $char\n"; 
#my $delta = 848;  # most of the mappings are offset by this amount
my $deltaChar = $char;  # default to input


my $cnum = ord($char); 
#print "cnum = $cnum\n"; 
if ($cnum == 0x0020) {

} else {
my $deltaNum = $cnum + $delta;
print "cnum = $cnum, delta = $delta\n"; 
print "deltaNum = $deltaNum\n"; 
$deltaChar = chr($deltaNum); 
print "changed $char to $deltaChar\n"; 
} # end if else space

$deltaChar; 
} # end delta F2C


# note this is restricted to the strictly Russian range
# there could be similarly encoded Ukrainian text, which would include the mappings
#  = 0404	= 0454
# = 0406	= 0456
# = 4047	= 0457
# = 0490	= 0491
# this encoding makes Russian look like "Finnish"
sub shifted848() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if ( ( ($cnum>=0x00C0)&&($cnum<=0x00FF)) || ($cnum==0x00B1) || ($cnum==0x0101)) {
$estne = 1;
#print "SHH shifted character: $c\n"; 
} # end if eng letter char range
$estne;
} # end sub shifted848


# now restricted to just the letters, not the symbols
sub english() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0041)&&($cnum<=0x007A)) {
$estne = 1;
} # end if eng letter char range
$estne;
} # end sub english

# don't use englishALL
sub englishALL() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0020)&&($cnum<=0x007E)) {
$estne = 1;
} # end if eng char range
$estne;
} # end sub englishALL

# Latin, Latin-1 supplement, and 0152 0153 OE oe
sub french() {
my $c = shift;
my $estne = 0;
my $cnum = ord($c);  #get codepoint
if ( (($cnum>=0x0041)&&($cnum<=0x007A)) || (($cnum>=0x00C0)&&($cnum<=0x00FF)) || ($cnum==0x0152) || ($cnum==0x0153) ) {
$estne = 1;
} # end if french char range
$estne;
} # end sub french

# TODO add presentation ranges
sub arabic() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0600)&&($cnum<=0x06FF)) {
$estne = 1;
} # end if 
$estne;
} # end sub arabic

sub greek() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0370)&&($cnum<=0x03FF)) {
$estne = 1;
} # end if 
$estne;
} # end sub greek

sub cyrillic() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0400)&&($cnum<=0x04FF)) {
$estne = 1;
} # end if 
$estne;
} # end sub cyrillic

sub ukrainian() {
	my $c = shift;
	my $estne = 0;
	#get codepoint
	my $cnum = ord($c);
	# if in Russian range, excluding 3 chars, or if one of the extra Ukrainian chars
	if  ( (   russian($c) && !russianOnly($c))|| (ukrainianOnly($c)) )  {
		#print "Ukrainian character: $c\n"; 
		$estne = 1;
	} else {
		#print "non-Ukrainian character: $c\n"; 
	}# end if
	$estne;
} # end sub ukrainian

# restrict to characters actually used in Russian, not whole Cyrillic range
# Russian range plus [yo] E: ё
sub russian() {
	my $c = shift;
	my $estne = 0;
	#get codepoint
	my $cnum = ord($c);
	#if (($cnum>=0x0400)&&($cnum<=0x04FF)) {
	if ( ( ($cnum>=0x0410)&&($cnum<=0x044F)) || ($cnum==0x0401) || ($cnum==0x0451)) {
		$estne = 1;
		###print "Russian character: $c\n"; 
	} # end if 
	$estne;
} # end sub russian

sub russianOnly() {
	my $c = shift;
	my $estne = 0;
	#get codepoint
	my $cnum = ord($c);
	if  ( ($cnum==0x042A) || ($cnum==0x042B) || ($cnum==0x04D) || ($cnum==0x044A) || ($cnum==0x044B) || ($cnum==0x044D)  ) {
		$estne = 1;
	} # end if 
	$estne;
} # end sub russianOnly


# perhaps omit Ukrainian 0406 І  because it can be used in Russian for Roman numerals 
# with lowercased input, worry about  0456 і as well -- but it is needed to distinguish many Ukrainian sentences which do not have the other special characters
sub ukrainianOnly() {
	my $c = shift; 
	my $estne = 0;
	#get codepoint
	my $cnum = ord($c);
	if ( ($cnum==0x0404) ||($cnum==0x0407) ||($cnum==0x0454) ||($cnum==0x0457) ||($cnum==0x0490) ||($cnum==0x0491)  || ($cnum==0x0456) || ($cnum==0x0406)) {
		$estne = 1; 
		#print "     Ukrainian special character, $c\n"; 
	} # end if	
	$estne;
} # end ukrainianOnly

# allow here any version of X, I, V
# Latin x X i I v V
# Cyrillic x X i I
# consider M, C, L
sub possibleRomanNumeral() {
	my $c = shift; 
	my $estne = 0;
	#get codepoint
	my $cnum = ord($c);
	if ( ($cnum==0x0406) ||($cnum==0x0456) ||($cnum==0x0069) ||($cnum==0x0049) ||($cnum==0x0445) ||($cnum==0x0425) ||($cnum==0x0078) ||($cnum==0x0058)  || ($cnum==0x0076) || ($cnum==0x0056)) {
		$estne = 1; 
	} # end if	
	$estne;
} # end possibleRomanNumeral

sub hindi() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0900)&&($cnum<=0x097F)) {
$estne = 1;
} # end if
$estne;
} # end sub hindi

#TODO -- add all the CJK ranges here
sub chinese() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (
(($cnum>=0x4E00)&&($cnum<=0x9FCB))||
(($cnum>=0x3400)&&($cnum<=0x4DB5)) ||
(($cnum>=0xF900)&&($cnum<=0x4FAD9)) # ||
) {
$estne = 1;
} # end if 
$estne;
} # end sub chinese

#TODO add others symbols here if needed 
# include 000A newline, to preserve badlastword value across blank lines
sub otherAllowed() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if ( ($cnum==0x000A) 
# || ($cnum==0x0000) 
) {
$estne = 1;
} # end if others char range
$estne;
} # end sub otherAllowed


# numerals included in the English character range
# 0030-0039 
sub englishNumerals() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0030)&&($cnum<=0x0039)) {
$estne = 1;
} # end if num char range
$estne;
} # end sub numerals



# considered limiting numbers to appropriate character sets... not currently used:
 
# now check numbers 
#$_ =$ci;
#if (
# (/\p{Number}/) 
# && (
#( ($englishflag==1)&&(/\p{Latin}/) ) ||  # working with english, have english number
#( ($greekflag==1)&&(/\p{Latin}/) ) ||  # working with greek, have english number
#( ($cyrillicflag==1)&&(/\p{Latin}/) ) ||  # working with cyrillic, have english number
#( ($arabicflag==1)&&(/\p{InArabic}/) ) ||  # working with arabic, have arabic number
#( ($hindiflag==1)&&(/\p{InDevanagari}/) ) ||  # working with hindi, have hindi number
#( ($chineseflag==1)&&(/\p{InCJK}/) ) # ||  # working with chinese, have chinese number
#) 
#) {
#$punctorsymbol = 1;
#print "found (appropriate) number: $ci\n";
#} # end if (appropriate) number
