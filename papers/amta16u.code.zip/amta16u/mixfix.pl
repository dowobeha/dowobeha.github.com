#!/usr/bin/perl
#
# this program should be applied after tokenization but before lowercasing
# use reportMixedLatinAndCyrillicCharacters.pl to count the number of problem words 
#
# this program identifies Cyrillic words that contain some Latin characters and converts them to all Cyrillic; similarly, mostly Latin words are converted to all Latin characters
# note that this conversion is restricted to characters with visual counterparts in both alphabets
#
# cейчас   first "c" is Latin, second "c" is Cyrillic
#  c 0063 е 0435 й 0439 ч 0447 а 0430 с 0441
# becomes all-Cyrillic:  сейчас
# 
# there are a few words like: oнa , a Russian word spelled with two English vowels o and a, and no English conversion possible for н; so even though the majority of characters are Latin, we allow a reverse conversion to all Cyrillic characters
#
# TODO there are still some false positives:  
# Latin-Cyrillic MP3плееры > all-Cyrillic МР3плееры  ("m. r. 3 player")
# we might consider a restriction based on all-caps

use strict;
use Getopt::Std;
binmode(STDOUT, ":utf8");
our($opt_i, $opt_o);
getopts("i:o:");
if(!$opt_i) {
    die "No input file specified with -i!\n";
}
if(!$opt_o) {
    die "No output file specified with -o!\n";
}
open (INFILE, $opt_i) or die "$0: Unable to open input file: $opt_i\n";
open (OUTFILE, ">$opt_o") or die "$0: Unable to open output file: $opt_o\n";
binmode(INFILE, ":utf8");
binmode(OUTFILE, ":utf8");
print "infile:  $opt_i\n";
print "outfile: $opt_o\n";

# these lists of equivalents tell us which characters we can convert to the other alphabet
# the actual conversion is done in e2c and c2e, below
# note that the Latin character 00EB ë may be converted to Cyrillic 0451 ё
# but there is no reason to convert 0451 ё to its Latin equivalent 00EB ë, so 0451 is not listed as one of the cyrillicEquivalents.  
# NOV 2013 added I because the non-Russian character 0406 is used in some Roman numerals

#TODO consider how lowercase 0456 Ukrainian і is sometimes used for i in English words in Russian text (e.g., Davіd, .іnfo, і_____)
my $cyrillicEquivalents = " \x{0430} \x{0435} \x{043A} \x{043E} \x{0440} \x{0441} \x{0443} \x{0445} \x{0410} \x{0412} \x{0415} \x{041A} \x{041C} \x{041E} \x{0420} \x{0421} \x{0422} \x{0423} \x{0425}  \x{041D} \x{0406} \x{0456} ";
my $latinEquivalents = " a e k o p c y x A B E K M O P C T Y X H \x{00EB} I i ";
# TODO evaluate whether to keep H; saw at least one example of Latin H for Cyrillic Н [n] 041D
# this fixed H in Hyжно (Latin H, Latin y) but disrupted H in СH4 (Cyrillic С Latin H)
#TODO consider adding m=\x{043C}, t =\x{0442} 
# have not included these now because the lowercase forms m and t are not visually similar to Cyrillic forms м and т .  

# these two forms show up in some Russian words, apparently marking stress
# we want to convert to a non-accented form, but still count these as Cyrillic forms
my $accentedCyrillic = " \x{00F2} \x{00F3} ";  # ò ó
my $hyphen = "-";  
my $cmix = 0;  # number of Russian words with some English chars
my $emix = 0;  # number of English words with some Cyrillic chars
my $cchanged = 0;  # number of changed Russian words
my $echanged = 0; # of changed English words
my $ocount = 0;  # number of words containing other characters
my $ochars = ""; # separated list of other characters
my $ocharlist = ""; # plain list of other characters
my $linenumber = 0;
my $accent0301Changed = 0;
my $accent00FxChanged = 0;
my $accentCount00Fx = 0;
my $cyrillicOcount = 0;  # mostly Cyrillic words containing other characters
my $cyrillicFcount = 0;  # mostly Cyrillic words containing 00F2 or 00F3 accented characters
my $cannot = 0;  # record mixed characters that cannot be properly mapped
my $rev2c = 0;  # more Latin characters, but can only map to Cyrillic
my $rev2e = 0;  # more Cyrillic characters, but can only map to Latin
my $escapeCount = 0;
my $escapeList = ""; 

while(my $row = <INFILE>) {
my $newrow;
chomp $row;
$linenumber++;

#   escape [ ]
my $lsb = "["; 
my $rsb = "]"; 
my $backslash = "\\"; 
$row =~ s/\[/ RSB /g;
$row =~ s/\]/ LSB /g;
$row =~ s/\\/ BACKSLASH /g; 
# added spaces to get these treated as separate words for conversion; previously we had errors like this: 
#  mostly English but some mixed characters can't be converted to English in программы%BACKSLASHko


my @words = split / /, $row;  

for (my $j=0; $j<@words; $j++) {
my $wordj = $words[$j];
my $originalWord = $wordj;
$wordj = processWord($wordj);	
if ($newrow eq "") {
	$newrow = $wordj;
} else {
	$newrow = $newrow." ".$wordj;
} # end if else nothing on row yet
} # end for word in row

# de-escape [ ]
$newrow =~ s/ RSB /$rsb/g;
$newrow =~ s/ LSB /$lsb/g;
$newrow =~ s/ BACKSLASH /$backslash/g; 

print OUTFILE $newrow."\n";
} # end while row

#my $total = $echanged + $cchanged + $rev2e + $rev2c + $accent0301Changed + $accent00FxChanged;
my $total = $echanged + $cchanged + $rev2e + $rev2c;
my $mixtotal = $total + $cannot;
my $etotal = $echanged + $rev2c;
my $ctotal = $cchanged + $rev2e;  
my $accenttotal = $accent0301Changed + $accent00FxChanged;
print "\n$mixtotal total number of words with mixed characters in $linenumber lines\n"; 
print "$total words with mixed characters changed to all Latin or all Cyrillic characters\n";
print "$cannot words with mixed characters that could not be converted\n";  
print "\tchanged $etotal of $emix mostly Latin words,\n\t\twith $echanged converted to all Latin characters\n\t\tand $rev2c reversals changing the original from mostly Latin to all Cyrillic\n"; 
print "\tchanged $ctotal of $cmix mostly Cyrillic words,\n\t\twith $cchanged converted to all Cyrillic characters\n\t\tand $rev2e reversals changing the original from mostly Cyrillic to all Latin\n"; 
print "\nremoved accents from $accenttotal accented words\n\t\tincluding $accent0301Changed instances of separate character 0301 \x{0301}\n\t\tand $accent00FxChanged instances of converting 00F2 \x{00F2} and 00F3 \x{00F3} to 043E \x{043E}\n";
#print "\tchanged $accent0301Changed of $cyrillicOcount mostly Cyrillic words that contain other, non-Latin characters, by removing separate accent 0301\n";
#print "\tchanged $accent00FxChanged of $cyrillicFcount mostly Cyrillic words that contain accented characters, by converting 00F2 \x{00F2} and 00F3 \x{00F3}to 043E \x{043E}\n";
print "\n$escapeCount words in which we did not attempt conversion because of presence of escape sequences like &apos;\n"; 
#print $escapeList."\n"; 
print "\nnote other unusual characters in file:  $ochars\n";

close INFILE;
close OUTFILE;

sub processWord() {
my $wordj = shift;
my $outword = "";
my $firstword = "";
my $punctuationMark = ""; 
my $residue = "";
my $newword = "";

#TODO  could restrict:  if word is all caps, do not change
# but we do find mixed characters in TED (should be ТED) and СNN (should be CNN)
my $allcaps = 0;
if ($wordj =~ /^[\p{IsUpper}\p{Number}]*$/) {
#print "all upper (or digit) $wordj\n";
$allcaps = 1;
} #end if all caps


#print "processWord sees $wordj\n";
# firstword is any sequence of characters from the start of the word, excluding hyphen
# residue is any characters following the hyphen
#if ($wordj =~ /^([^\-]+)(\-)(.+)/) {
# changed this to all punctuation in class
# TODO expand punctuation list to include parens, apostrophe, ` , underbar, ://
#if ($wordj =~ /^([^\-]+)(\p{Punctuation})(.+)/) {
if ($wordj =~ /^(\P{Punctuation}+)(\p{Punctuation})(.+)/) {
	#print "$wordj matches\n";
	$firstword = $1;
	$punctuationMark = $2; 
	$residue = $3;	
	#print "hyphenated:  $firstword and $residue\n";
	$outword = processWord($firstword);
	#print "after first part $firstword of hyphenated word $wordj, we have $outword\n";
	# restore hyphen with no spaces; check remainder of word after hyphen
	#$outword = $outword.$hyphen.processWord($residue);  
	 $outword = $outword.$punctuationMark.processWord($residue);  
	#print "after second part $residue of hyphenated word $wordj, we have $outword\n";
        
} else { 
# process word or sub-word without internal hyphens:


# add a step to screen out Moses tokenizer escape sequences &apos; &quot;
# also screen out sequence nbsp (non-breaking space) which sometimes occurs attached to words in the phrase table (poor HTML formatting)
if (  ($wordj =~ /\&apos;/) ||  ($wordj =~ /\&quot;/) ||($wordj =~ /\&amp;/) ||($wordj =~ /\&#124;/) ||($wordj =~ /\&lt;/) ||($wordj =~ /\&gt;/) ||($wordj =~ /\&#91;/) ||($wordj =~ /\&#93;/) ||($wordj =~ /nbsp/)  ){
	print "found escape sequence in $wordj so no conversions attempted\n"; 
	$escapeCount++;  
	$escapeList = $escapeList." ".$wordj; 
} else {

my $englishn = 0;
my $cyrillicn = 0;
my $othern = 0;
my $accentCountChars0301 = 0;
my $accentCountChars00Fx = 0;
my $code = "";
# might want to report codepoints so we can tell the characters apart
#my $codepoints = "";
my @cs = split //, $wordj;
for (my $i=0; $i<@cs; $i++) {
my $ci = $cs[$i];
# might want to report codepoints so we can tell the characters apart
#my $cnum = sprintf('%2.4x', unpack('U0U*', $ci));  
#$codepoints = $codepoints." ".$cnum;  
$_ = $ci;

# this step is just for counting, no changes are made yet
if (!otherAllowed($ci)) {
if ((/\P{Punctuation}/)&&(/\P{Symbol}/)&&(/\P{Number}/)) {
#print "considering $ci\n";
	if (englishAndYo($ci)) {
		$englishn++; 
		$code = $code."E";
		}
	elsif (cyrillic($ci)) {
		$cyrillicn++; 
		$code = $code."C";
		}
	elsif ($accentedCyrillic =~ /$ci/) {
		# later, convert to non-accented forms
		$accentCountChars00Fx++;
		$code = $code."A";	
	} else {	
		$othern++;
		$code = $code."O";		
		if ($ochars =~ /$ci/) {
			# already have it
		} else {
			$ochars = $ochars."   ".$ci;
			$ocharlist =$ocharlist.$ci;
		}
	} # end if else English, Cyrillic, accented Cyrillic, or other
} # end if not symbol or punct
} # end if not otherAllowed
} # end for chars

if ($othern>0) {
	$ocount++;
} # end if other chars are present

if ($accentCountChars00Fx>0) {
	$accentCount00Fx++;
} # end if accented characters are present



$outword = $wordj;
# first convert any accented forms within Russian words
	my $inword = $outword;
if (($cyrillicn>=$othern)&&($othern>0)) {
	# check for and remove separate accent mark 0301
	$cyrillicOcount++;  
	$outword =~ s/\x{0301}//g;
	# count any changes
	if ($outword ne $inword) {
		$accent0301Changed++;
		print "removed accent mark from $inword creating $outword\n";
	} # end if changed	
} # end remove separate accent

# reset character buffer
my @cs = split //, $outword;
# handle accented characters
if (($cyrillicn>=$accentCountChars00Fx)&& ($accentCountChars00Fx>0)) {
	$cyrillicFcount++;  
	# convert accented  ò and  ó to non-accented o		
	for (my $i=0; $i<@cs; $i++) {
		my $ci = $cs[$i];
		$ci = nonAccented($ci);
		$newword = $newword.$ci;	
	} # end for i
		# count any changes
		if ($newword ne $outword) {
			$accent00FxChanged++;	
			print "changed accented $outword to unaccented $newword\n";
		} else {
			print "unchanged:  $outword\n";
		} # end if changed		
	$outword = $newword;
} # end if accented

if (($englishn>$cyrillicn)&&($cyrillicn>0)) {
$emix++;
#possible Russian in the English
	# go back through the characters
	my $canconvert = 1;  
	for (my $i=0; $i<@cs; $i++) {
		my $ci = $cs[$i];
		if (cyrillic($ci)) {
			if	($cyrillicEquivalents =~ /$ci/) {
				# convert Russian character to English equivalent
				my $ec = c2e($ci);
				$newword = $newword.$ec;
			} else {
				$canconvert = 0;
			} # end if else convertible Cyrillic character
		} else {
			# keep English character
			 $newword = $newword.$ci;  		
		} # end if else Cyrillic character
	} #end for i chars
	if ($canconvert==1) {
		$echanged++;
		print "changed $outword to all Latin $newword\n";
		$outword = $newword;
	} else {
		print ">>> mostly English but some mixed characters can't be converted to English in $outword";
		$cannot++; 
		# try the reverse conversion:  change all Latin characters to Cyrillic
		my $reverseE2C = 1;
		my $reverseWord = "";
		print "\n"; 
		for (my $i=0; $i<@cs; $i++) {
			my $ci = $cs[$i];	
			if (englishAndYo($ci)) {
				# convert English character to Russian equivalent
				if ($latinEquivalents =~ /$ci/) {
					my $ce = e2c($ci);
					$reverseWord = $reverseWord.$ce;
				} else {
					# mark as no good
					$reverseE2C = 0;
				} # end if else can convert char
			} else {
				$reverseWord = $reverseWord.$ci;
			} # end if else English
		} # end for i chars		
			if ($reverseE2C == 1) {
				$outword = $reverseWord;
				print " -- succeeded in the reverse English to Cyrillic conversion, $reverseWord\n";
				$cannot--; 
				$rev2c++; 
			} else {
				print "\n";  
			} ## end if else reversal works 
	} # end if else every Cyrillic character was converted

} elsif (($cyrillicn>=$englishn)&&($englishn>0)) {
#possible English in the Russian
$cmix++;
	# go back through the characters
	my $canconvert = 1;  
	for (my $i=0; $i<@cs; $i++) {
		my $ci = $cs[$i];
		if (englishAndYo($ci)) {
			if	($latinEquivalents =~ /$ci/) {
				# convert English character to Cyrillic equivalent
				my $cc = e2c($ci);
				$newword = $newword.$cc;
			} else {
				$canconvert = 0;
			} # end if else convertible English character
		} else {
			# keep Cyrillic character
			$newword = $newword.$ci;  
		} # end if else English character
	} #end for i chars
	if ($canconvert==1) {
		$cchanged++;
		print "changed $outword to all Cyrillic $newword\n";
		$outword = $newword;
	} else {
	print ">>> mostly Cyrillic but some mixed characters can't be converted to Cyrillic in $outword";
		$cannot++;
			# try the reverse conversion:  change all Cyrillic characters to Latin
		my $reverseC2E = 1;
		my $reverseWord = "";
		for (my $i=0; $i<@cs; $i++) {
			my $ci = $cs[$i];
			if (cyrillic($ci)) {
				# convert Russian character to English equivalent
				if ($cyrillicEquivalents =~ /$ci/) {
					my $ec = c2e($ci);
					$reverseWord = $reverseWord.$ec;
				} else {
					# mark as no good
					$reverseC2E = 0;
				} # end if else can convert char
			} else {
				$reverseWord = $reverseWord.$ci;
			} # end if else English	
		} # end for i chars		
			if ($reverseC2E == 1) {
				$outword = $reverseWord;
				print " -- succeeded in the reverse Cyrillic to English conversion, $reverseWord\n";
				$cannot--;  
				$rev2e++; 
			} else {
				print "\n";  
			} #end if else reversal works 
	} # end if else every English character was converted
	
} # end if Russian or English word with mixed characters

} # end if else contains escape sequences &apos; &quot
} # end if else hyphenated

#TODO this is for checking on words that would be affected by a possible restriction on changing strings of all caps
# note this does not catch allcaps substrings like MP3плееры
# check on allcaps
#  if (($allcaps == 1)&&($outword ne $wordj)) {
	#  print "note:  current code changes allcaps $wordj to $outword\n";
#  } # end if changed all caps

$outword;
} # end sub processWord

sub nonAccented() {
my $char = shift;
# convert accented cyrillic chars to non-accented versions
$char =~   s/\x{00F2}/\x{043E}/g;   # ò becomes о
$char =~   s/\x{00F3}/\x{043E}/g;   # ó becomes о

$char;
} # end sub nonAccented

sub e2c() {
my $char = shift;
# convert latin chars to visual cognates in cyrillic
$char =~     s/a/\x{0430}/g; 
$char =~     s/e/\x{0435}/g; 
$char =~     s/k/\x{043A}/g; 
$char =~     s/o/\x{043E}/g; 
$char =~     s/p/\x{0440}/g; 
$char =~     s/c/\x{0441}/g; 
$char =~     s/y/\x{0443}/g; 
$char =~     s/x/\x{0445}/g; 

$char =~     s/A/\x{0410}/g; 
$char =~     s/B/\x{0412}/g; 
$char =~     s/E/\x{0415}/g; 
$char =~     s/K/\x{041A}/g; 
$char =~     s/M/\x{041C}/g; 
$char =~     s/O/\x{041E}/g; 
$char =~     s/P/\x{0420}/g; 
$char =~     s/C/\x{0421}/g; 
$char =~     s/T/\x{0422}/g; 
$char =~     s/Y/\x{0423}/g; 
$char =~     s/X/\x{0425}/g; 

$char =~     s/H/\x{041D}/g; 

$char =~     s/I/\x{0406}/g;   # in Roman numerals

# not in English range but we want to convert it as if it were English
$char =~ s/\x{00EB}/\x{0451}/g;  # 0451 ё, 00EB ë

# $char =~     s/m/\x{043C}/g;   # not similar?
# $char =~     s/t/\x{0442}/g;   # not similiar?
$char;
} # end sub e2c

sub c2e() {
my $char = shift;
# convert cyrillic chars to visual cognates in latin
$char =~   s/\x{0430}/a/g; 
$char =~    s/\x{0435}/e/g; 
$char =~    s/\x{043A}/k/g; 
$char =~    s/\x{043E}/o/g; 
$char =~    s/\x{0440}/p/g; 
$char =~    s/\x{0441}/c/g; 
$char =~    s/\x{0443}/y/g; 
$char =~    s/\x{0445}/x/g; 

$char =~     s/\x{0410}/A/g; 
$char =~     s/\x{0412}/B/g; 
$char =~     s/\x{0415}/E/g; 
$char =~     s/\x{041A}/K/g; 
$char =~     s/\x{041C}/M/g; 
$char =~     s/\x{041E}/O/g; 
$char =~     s/\x{0420}/P/g; 
$char =~     s/\x{0421}/C/g; 
$char =~     s/\x{0422}/T/g; 
$char =~     s/\x{0423}/Y/g; 
$char =~     s/\x{0425}/X/g; 

$char =~     s/\x{0406}/I/g;   # in Roman numerals
$char =~     s/\x{0456}/i/g;   # in some Latin words

$char =~     s/\x{041D}/H/g;   # unattested
#$char =~    s/\x{0442}/t/g;   # not similiar?
#$char =~    s/\x{043C}/m/g;   # not similar?  
$char;
} # end sub c2e

# revised to include non-Cyrillic variant of 0451 ё, 00EB ë
sub englishAndYo() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0041)&&($cnum<=0x007A)) {
$estne = 1;
} # end if eng letter char range
if ($cnum==0x00EB) {
$estne = 1;
} # end if 
$estne;
} # end sub english

# restricted to just the letters, not the symbols
sub english() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0041)&&($cnum<=0x007A)) {
$estne = 1;
} # end if eng letter char range
$estne;
} # end sub english

sub cyrillic() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0400)&&($cnum<=0x04FF)) {
$estne = 1;
} # end if 
$estne;
} # end sub cyrillic

# add others symbols here if needed 
# 000A = line feed
# added soft hyphen 00AD
sub otherAllowed() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if ( ($cnum==0x000A) || ($cnum==0x00AD) 
# || ($cnum==0x0000) 
) {
$estne = 1;
} # end if others char range
$estne;
} # end sub otherAllowed

