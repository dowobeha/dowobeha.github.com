#!/usr/bin/perl
#
# given the name of the source and target languages, remove any foreign words
# e.g., when looking at French/English training files, we first remove any instances of Greek or Arabic or Cyrillic words
#
# words with mixed-alphabets are retained
# e.g., keep the name Danica Simšic, even though š is out of the French/English character ranges
#
# removeForeignWords.pl -i INPUT -o OUTPUT -b BADCHARS -k SOURCE,TARGET
#
# removeForeignWords.pl -i testfile -o testfile-keep-english-french -b testfile-keep-english-french-badchars -k english,french
#
# where -k is a list of languages to keep, as defined in the subroutines below
# and -b is a file that list the characters that are removed (for debugging)
# option -n prints the original line numbers (good for identifying where the file has foreign sections)
#
# if the entire line is removed, we output a blank line (this keeps parallel files parallel)
#
# only certain language and/or script names are supported:  
# english, french, arabic, cyrillic, hindi, chinese, greek
# TODO:  finish adding ranges to arabic, chinese
#
# >> to define a new language range, copy and edit the french subroutine, below.
# 
# you may be able to use existing Unicode properties:
# 	InArabic, InCyrillic, InDevanagari, InGreek, etc.
# 	note also InArabicPresentationForms-A, -B, etc. 
# 
# or you may have to define specific ranges:  French = 00C0-00FF
# 	note that additional characters may be needed beyond the main code block
#  	(for French, we add OE 0152 and oe 0153)
#
# sub french() {
# my $c = shift;
# my $estne = 0;
# my $cnum = ord($c);  #get codepoint
# if ( (($cnum>=0x00C0)&&($cnum<=0x00FF)) || ($cnum==0x0152) || ($cnum==0x0153) ) {
# $estne = 1;
# } # end if french char range
# $estne;
# } # end sub french


use strict;
use Getopt::Std;

binmode(STDOUT, ":utf8");

our($opt_i, $opt_o, $opt_b, $opt_k, $opt_n);
getopts("i:o:b:k:n");

if(!$opt_i) {
    die "No input file specified with -i!\n";
}

if(!$opt_o) {
    die "No output file specified with -o!\n";
}

if(!$opt_b) {
    die "No bad character output file specified with -b!\n";
}

if(!$opt_k) {
    die "No languages to keep specified with -k!\n";
}

open (INFILE, $opt_i) or die "$0: Unable to open input file: $opt_i\n";
open (OUTFILE, ">$opt_o") or die "$0: Unable to open output file: $opt_o\n";
open (OUTFILE2, ">$opt_b") or die "$0: Unable to open output file: $opt_b\n";

binmode(INFILE, ":utf8");
binmode(OUTFILE, ":utf8");
binmode(OUTFILE2, ":utf8");

print "infile:  $opt_i\n";
print "outfile: $opt_o\n";
print "outfile2: $opt_b\n";
print "keep languages: $opt_k\n";
print "number lines? $opt_n\n";


# number lines option
my $linenumbering = 0;
if ($opt_n) {
$linenumbering = 1;
} # end if

# parse the list of languages (these must match the subroutines)
my $englishflag = 0;
my $frenchflag = 0;
my $arabicflag = 0;
my $cyrillicflag = 0;
my $greekflag = 0;
my $hindiflag = 0;
my $chineseflag = 0;

my $langlist = $opt_k;

my @langwords = split/,/, $langlist;
for (my $i=0; $i<@langwords; $i++) {
my $wordi = $langwords[$i];

$_ = $wordi;
if (/^english$/i) {
$englishflag =1;
} elsif (/^french$/i) {
$frenchflag = 1;
} elsif (/^arabic$/i) {
$arabicflag = 1;
} elsif (/^cyrillic$/i) {
$cyrillicflag = 1;
} elsif (/^greek$/i) {
$greekflag = 1;
} elsif (/^hindi$/i) {
$hindiflag = 1;
} elsif (/^chinese$/i) {
$chineseflag = 1;
} else {
print "unknown language range, $wordi\n";
} # end find word

} # end for word in list


my $badchars = " ";
my $plusalready = 0;  # must trap for '+' separately

my $badlastword = 0;  # persists across rows

my $linenumber = 0;

while(my $row = <INFILE>) {
my $newrow;
#print "new row: $row\n";
#print "variable badlastword = $badlastword\n";
$linenumber++;


my @words = split / /, $row;
for (my $j=0; $j<@words; $j++) {
my $wordj = $words[$j];

#print "word >>$wordj<<\n";


# if at least one good character (French or English letters), keep
# if all symbols/punc, keep
# if bad letters with attached punc/symbol, toss
# if all bad letters, toss

# abc
# 13,
# друг7,
# друг

my $badword = 1;  #assume it is guilty
my $symbolsonly = 1;  # assume it is all symbols

my @cs = split //, $wordj;
for (my $i=0; $i<@cs; $i++) {
my $ci = $cs[$i];

# language classes should include letters only, not symbols or numbers
if ( 
((english($ci))&($englishflag==1)) || 
((french($ci))&($frenchflag==1)) || 
((arabic($ci))&($arabicflag==1)) || 
((greek($ci))&($greekflag==1)) || 
((cyrillic($ci))&($cyrillicflag==1)) ||
((hindi($ci))&($hindiflag==1)) ||
((chinese($ci))&($chineseflag==1)) #||
) {

$badword = 0;  # at least one good character, so keep this word
$symbolsonly = 0;  # not all symbols/punctuation
} else {

# TODO -- split Number set into "English" vs. "Arabic" vs. "Chinese" etc.

# if new, and if not a number or punctuation symbol, add to bad character list
# note: capital \P = 'not'
# note: currency symbols are included in the set, Symbol
$_ = $ci;
if (
(/\P{Punctuation}/) &&(/\P{Symbol}/) && (!otherAllowed($ci) &&(/\P{Number}/))
) {
# print "char $ci is not punctuation,symbol,otherAllowed, or number\n";
$symbolsonly = 0;  # at least one char that is not in target language(s), and not a symbol or punctuation character
$_ = $badchars;
# only save new ones
#print "debug: badchar $ci\n";
# first trap for quantifier, causes error in matching clause  << already trapped above?
if ($ci == '+') {
# if (($ci == '+')&&($plusalready==0)) {
# $plusalready = 1;
$badchars = $badchars.$ci.' ';
print OUTFILE2 $ci.' ';
} elsif (!/$ci/) {
$badchars = $badchars.$ci.' ';
print OUTFILE2 $ci.' ';
} # end if don't already have badchar

} # end if not symbol -- don't store symbols
} # end if else allowed character
} # end for char in word

# if the word consists only of symbols/punc/numbers, 
# and we are not in a foreign section of text, keep it
# key on previous word:
#
# alpha beta 123    -- keep 123
# новых новых 123   -- toss 123
#
# for a row of isolate symbols:  keep if preceding row is not foreign
# alpha beta
# 123			-- keep 123
#
# новых новых
# 123			-- toss 123
#
# use a badlastword flag that persists across rows
#
#
# TODO:  mixed text:  keep
# новых новых 123 alpha  -- keep 123 
#
# TODO:  mixed text:  keep
# новых новых
# 123			-- keep 123
# alpha beta
#

if (($symbolsonly)&&(!$badlastword)) {
$badword = 0;
} # end if all symbols/punc

if (!$badword) {
$newrow = $newrow.$wordj.' ';  # note: final space removed below
$badlastword = 0;
} else {
$badlastword = 1;
} # end if else word has no bad characters
#print "saw word $wordj, badlastword = $badlastword\n";
} # end for word in row

# check row for all punc, if so, remove
# allow all numbers (no mention here)
# allow currency signs even in isolation

my $allpunc = 1; # assume it's guilty until we've checked each char
my @checkrow = split //, $newrow;
for (my $j=0; $j<@checkrow; $j++) {
my $cj = $checkrow[$j];

# if character is not space, punct, symbol, or otherAllowed, row is no longer allpunc
# or, if character is a currency symbol (subset of symbol), row is no longer allpunc
$_ = $cj;
if ( 
(/\p{Sc}/) ||
( (/\S/)&&(/\P{Punctuation}/)&&(/\P{Symbol}/)&&(!otherAllowed($cj)) )
) {
$allpunc = 0;  # found something not punc
} # end if

} # end for char in row

# if row is not all punctuation, print it out
if ($allpunc==0) {
    chomp $newrow;
    $newrow =~ s/\s+/ /g;
    $newrow =~ s/^\s+//;
    $newrow =~ s/\s+$//;

if ($linenumbering) {
print OUTFILE "$linenumber//$newrow\n";
} else {
print OUTFILE "$newrow\n";
} # end if else number the lines with original line numbers

} else {
# either allpunc, or blank (no characters means no chance to declare not all punc)
# print a blank line
if ($linenumbering) {
print OUTFILE "$linenumber//\n";
} else {
print OUTFILE "\n";
} # end if else number the lines with original line numbers


} # end if else not all punctuation


} # end while row


close INFILE;
close OUTFILE;
close OUTFILE2;


# now restricted to just the letters, not the symbols
sub english() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0041)&&($cnum<=0x007A)) {
$estne = 1;
} # end if eng letter char range
$estne;
} # end sub english

# don't use englishALL
sub englishALL() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0020)&&($cnum<=0x007E)) {
$estne = 1;
} # end if eng char range
$estne;
} # end sub englishALL

# Latin, Latin-1 supplement, and 0152 0153 OE oe
sub french() {
my $c = shift;
my $estne = 0;
my $cnum = ord($c);  #get codepoint
if ( (($cnum>=0x0041)&&($cnum<=0x007A)) || (($cnum>=0x00C0)&&($cnum<=0x00FF)) || ($cnum==0x0152) || ($cnum==0x0153) ) {
$estne = 1;
} # end if french char range
$estne;
} # end sub french

# TODO add presentation ranges
sub arabic() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0600)&&($cnum<=0x06FF)) {
$estne = 1;
} # end if 
$estne;
} # end sub arabic

sub greek() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0370)&&($cnum<=0x03FF)) {
$estne = 1;
} # end if 
$estne;
} # end sub greek

sub cyrillic() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0400)&&($cnum<=0x04FF)) {
$estne = 1;
} # end if 
$estne;
} # end sub cyrillic

sub hindi() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0900)&&($cnum<=0x097F)) {
$estne = 1;
} # end if
$estne;
} # end sub hindi

#TODO -- add all the CJK ranges here
sub chinese() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (
(($cnum>=0x4E00)&&($cnum<=0x9FCB))||
(($cnum>=0x3400)&&($cnum<=0x4DB5)) ||
(($cnum>=0xF900)&&($cnum<=0x4FAD9)) # ||
) {
$estne = 1;
} # end if 
$estne;
} # end sub chinese

#TODO add others symbols here if needed 
# include 000A newline, to preserve badlastword value across blank lines
sub otherAllowed() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if ( ($cnum==0x000A) 
# || ($cnum==0x0000) 
) {
$estne = 1;
} # end if others char range
$estne;
} # end sub otherAllowed


# numerals included in the English character range
# 0030-0039 
sub englishNumerals() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0030)&&($cnum<=0x0039)) {
$estne = 1;
} # end if num char range
$estne;
} # end sub numerals



# considered limiting numbers to appropriate character sets... not currently used:
 
# now check numbers 
#$_ =$ci;
#if (
# (/\p{Number}/) 
# && (
#( ($englishflag==1)&&(/\p{Latin}/) ) ||  # working with english, have english number
#( ($greekflag==1)&&(/\p{Latin}/) ) ||  # working with greek, have english number
#( ($cyrillicflag==1)&&(/\p{Latin}/) ) ||  # working with cyrillic, have english number
#( ($arabicflag==1)&&(/\p{InArabic}/) ) ||  # working with arabic, have arabic number
#( ($hindiflag==1)&&(/\p{InDevanagari}/) ) ||  # working with hindi, have hindi number
#( ($chineseflag==1)&&(/\p{InCJK}/) ) # ||  # working with chinese, have chinese number
#) 
#) {
#$punctorsymbol = 1;
#print "found (appropriate) number: $ci\n";
#} # end if (appropriate) number
