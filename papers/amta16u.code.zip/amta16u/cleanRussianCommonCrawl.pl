#!/usr/bin/perl

# in the commoncrawl data, some French, German, and Spanish sentences are included, presumably because they include Cyrillic characters
#  these are due to a bad encoding in which accented characters are replaced with Cyrillic
#  parfum de sйquoia, notes boisйes de cиdres...
#  й = é     и =  è    etc.

# this program screens out "Russian" lines which are really other languages using the Latin alphabet with some Cyrillic characters
# this program takes two, parallel input files, screens based on the first, Russian file, and outputs parallel files for the Russian and the English:  
# Russian good, English good, Russian bad, English bad
#
# we want to keep lines with sequences of Cyrillic characters:   
# ECCCC  might be an example of a different error, in which the writer uses some visually-similar Latin characters for Russian letters (subsequently, apply normalizeMixedLatinAndCyrillicCharacters.pl)
# CCCEEECCCCC might be an example of a borrowed English word, such as a URL or NE
#
# we want to remove lines with isolated Cyrillic characters:
# EECEE and ECEC are probably encoding errors as described above

# this version also attempts to detect and remove sentences that are in Ukrainian
# which uses the Cyrillic characters, but adds 4 and lacks 3 compared to Russian

# we also detect and decipher text that has undergone the encoding shift -848 (probably derived from a conflict between ISO and UTF8)

use strict;
use Getopt::Std;
binmode(STDOUT, ":utf8");
our($opt_r, $opt_e);
getopts("r:e:");
if(!$opt_r) {
    die "No Russian input file specified with -r!\n";
}
if(!$opt_e) {
    die "No English input file specified with -e!\n";
}
open (INRU, $opt_r) or die "$0: Unable to open input file: $opt_r\n";
open (INEN, $opt_e) or die "$0: Unable to open input file: $opt_e\n";
my $goodRussian = $opt_r."-keepR";
my $badRussian = $opt_r."-nonR"; 
my $goodEnglish = $opt_e."-keepR-parallel";
my $badEnglish = $opt_e."-nonR-parallel"; 
open (RGOODLINES, ">$goodRussian") or die "$0: Unable to open output file: $goodRussian\n";
open (RBADLINES, ">$badRussian") or die "$0: Unable to open output file: $badRussian\n";
open (EGOODLINES, ">$goodEnglish") or die "$0: Unable to open output file: $goodEnglish\n";
open (EBADLINES, ">$badEnglish") or die "$0: Unable to open output file: $badEnglish\n";
binmode(INRU, ":utf8");
binmode(INEN, ":utf8");
binmode(RGOODLINES, ":utf8");
binmode(RBADLINES, ":utf8");
binmode(EGOODLINES, ":utf8");
binmode(EBADLINES, ":utf8");

print "Russian infile:  $opt_r\n";
print "English infile: $opt_e\n"; 
print "goodlines: $goodRussian\n";
print "badlines: $badRussian\n";
print "with matching English files,\n";
print "goodlines: $goodEnglish\n";
print "badlines: $badEnglish\n"; 

#minimum proportion of Cyrillic required
my $min = 0.33; 
my $linenumber = 0; 
my $goodcount = 0;
my $badcount = 0; 
my $isolateCount = 0; 
my $truecount = 0; 
my $ukrainianCharacterMax = 0.00;  # allow some misc Ukrainian characters for borrowed words?  
my $ukrainianBadcount = 0;  
my $shiftpossibles = 0; 
my $didshift = 0;  
my $blankcount = 0; 

while(my $row = <INRU>) {
my $erow = <INEN>; 

my $newrow1=$row;
chomp $row;
chomp $erow;

my $len = length($row); 
if ($len > 0) {

$linenumber++;
my $russianN = 0;
my $nonRussianN = 0; 
my $ukrainianN = 0;
my $russianRoman = 0;
my $nonRussianRoman = 0;
my $ukrainianRoman = 0; 
my $gheWithUpturn = 0; 
my $shift848N = 0; 
my $couldshift = 0;  # record FFF > CCC, then later count if we used that line with $didshift


# screen out leftover escape sequences -- don't count these
$newrow1 =~ s/\&amp;//g;
$newrow1 =~ s/\&apos;//g;
$newrow1 =~ s/\&quot;//g;
$newrow1 =~ s/\&lt;//g;
$newrow1 =~ s/\&gt;//g;
$newrow1 =~ s/\&#124;//g;
$newrow1 =~ s/\&#91;//g;
$newrow1 =~ s/\&#93;//g;
$newrow1 =~ s/\&nbsp//g;
$newrow1 =~ s/nbsp//g;
$newrow1 =~ s/ampquot//g;

# first decipher any shifted encodings
# detect and code these characters based on the escaped row (no &amp;), but
# make the shift on the original row; escape sequences will not be shifted since they are out of range
# TODO currently, we only decipher if entire line is encoded

# print "SHH $newrow1\n"; 
my $tempchar1 = ""; 
my $code1 = ""; 
my @chars = split //, $newrow1;  
for (my $i=0; $i<@chars; $i++) {
	my $ci = $chars[$i];
# might want to report codepoints so we can tell the characters apart
#my $cnum = sprintf('%2.4x', unpack('U0U*', $ci));  
#$codepoints = $codepoints." ".$cnum;  
my $cnum = ord($ci); 
	$_ = $ci;
	if (!otherAllowed($ci)) {
		if ((/\P{Punctuation}/)&&(/\P{Symbol}/)&&(/\P{Number}/)) {
		
		if (shifted848($ci)) {
			$shift848N++;
			$tempchar1 = "F";  # because it looks like Finnish
			$code1 = $code1.$tempchar1;
		} elsif ($cnum==0x0020) {
			$code1 = $code1." "; 
			$code1 = $code1.$tempchar1;
		} else {
			$tempchar1 = "X";  # the unknown
			$code1 = $code1.$tempchar1;
		} # end if else shifted
	} else {
		$code1 = $code1."P"; 
	} # end if else not punct
} # end if not other allowed

} # end for chars
#	print $row."\n";
#	print $code1."\n"; 			
# shifted encoding 848
my $newcode = $code1;
#$newcode =~ s/P//g;  # remove punct codes
#$newcode =~ s/ //g;  # remove spaces from the code
#	print $newcode."\n"; 
	# must have at least 3 consecutive potential shifted encoding characters
if ($newcode =~ /FFF/) {
	$shiftpossibles++; 
	$couldshift = 1; 
	print "POSSIBLE SHIFTED ENCODING: >>$row<<\n"; 
	#debug:
	# print "SHH shift:    $newrow1\n";
	# print "SHH code1:  $code1\n"; 
	my $shiftedrow = ""; 
	my @cs = split //, $row;
	for (my $i=0; $i<@cs; $i++) {
		my $ci = $cs[$i];
		my $newi = deltaF2C($ci); 
		$shiftedrow= $shiftedrow.$newi;
	} # end for chars in row
	
	# at this point, any shifted character is now a Russian character
	# and will be detected and coded as such in the next section
	$row = $shiftedrow; 
	#$code =~ s/F/R/g;	
} # end if all shifted characters (or punct or space)

# escape again for main processing section
my $newrow = $row; 

# screen out leftover escape sequences -- don't count these
$newrow =~ s/\&amp;//g;
$newrow =~ s/\&apos;//g;
$newrow =~ s/\&quot;//g;
$newrow =~ s/\&lt;//g;
$newrow =~ s/\&gt;//g;
$newrow =~ s/\&#124;//g;
$newrow =~ s/\&#91;//g;
$newrow =~ s/\&#93;//g;
$newrow =~ s/\&nbsp//g;
$newrow =~ s/nbsp//g;
$newrow =~ s/ampquot//g;
# print "SHH $newrow\n"; 
my $tempchar = ""; 
my $code = ""; 
my @chars = split //, $newrow;  
for (my $i=0; $i<@chars; $i++) {
	my $ci = $chars[$i];
# might want to report codepoints so we can tell the characters apart
#my $cnum = sprintf('%2.4x', unpack('U0U*', $ci));  
#$codepoints = $codepoints." ".$cnum;  
my $cnum = ord($ci); 
	$_ = $ci;
	if (!otherAllowed($ci)) {
		if ((/\P{Punctuation}/)&&(/\P{Symbol}/)&&(/\P{Number}/)) {
			if (russian($ci)) {
				$russianN++; 
				#$code = $code."C"; 
				$tempchar = "C"; 
					if (possibleRomanNumeral($ci)) {
						$russianRoman++; 
						#$code = $code."K"; 
						$tempchar = "K"; 
					} # end if it might be a Roman numeral
				$code = $code.$tempchar; 
			} elsif (ukrainianOnly($ci)) {
				$ukrainianN++;
				#$code = $code."U"; 
				$tempchar = "U"; 
				
				# allow use if Ukrainian І as part of a Roman numeral
				# don't consider lowercase Ukrainian і
				if ($cnum==0x0406) {
					$ukrainianRoman++; 
					#$code = $code."I"; 
					$tempchar = "I"; 
				} # end if it might be a Roman numeral
				
				# screen for  ґ  which can be used as an apostrophe
				if (($cnum==0x0490)||($cnum==0x0491)) {
					#print "found ghe:  cnum $cnum, char $ci\n"; 
					$gheWithUpturn++; 
					#$code = $code."G"; 
					$tempchar = "G"; 
				} # end if  ґ 
				$code = $code.$tempchar; 
			} elsif ($cnum==0x0020) {
				$code = $code." "; 
			} else {
				$nonRussianN++;  
				#$code = $code."N"; 
				$tempchar = "N"; 
				if (possibleRomanNumeral($ci)) {
					$nonRussianRoman++; 
					#$code = $code."M"; 
					$tempchar = "M"; 
				} # end if it might be a Roman numeral
				$code = $code.$tempchar; 
			} # end if else russian
		
		} else {
			$code = $code."P"; 
		}# end if else not punct or digit
	} # end if not line feed
} # end for chars in line
# print "SHH $code\n"; 





#  ґ used as apostrophe
# looking for sequences like NG MG  NGN  MGM  etc.
# if found, convert ґ in the original row
# TODO deal with multiple occurrences 
#	currently replaces all ґ if context is met for at least one
#	currently reduces count of Ukrainian-specific characters by one only
# make changes in the original, non-escaped row
my $startrow = $row; 
my $startcode = $code; 
	if ($code =~ /(N)(G)/) {
		# print "SHH  found NG\n"; 
		$row =~ s/\x{0490}/\'/g;
		$row =~ s/\x{0491}/\'/g;
		$ukrainianN--; 
	} elsif  ($code =~ /(M)(G)/) {
		# print "SHH  found MG\n"; 
		$row =~ s/\x{0490}/\'/g;
		$row =~ s/\x{0491}/\'/g;
		$ukrainianN--; 
	} 
#print "row becomes $row\n"; 
if ($startrow ne $row) {
	print "APOSTROPHE CONVERSION: $startrow >>> $row\n"; 
} # end if changed


# Roman numerals
if (($code =~ /I/) && (($code =~ /K/) || ($code =~ /M/)) ) {

#print "initial code is $code\n";
#print "where Ukrainian chars are U/I/G, Russian characters are C/K, others are N/M, punct is P\n and I,K,M are possible Roman numeral counterparts\n"; 
#print "before considering possible Roman numerals, count of Ukrainian-specific characters is $ukrainianN\n"; 

# look for Ukrainian-specific elements that might be part of a Roman numeral
# trap for IK  IM  KI  MI
# only discount each I once
# e.g. KIK counts as one I discount
# TODO convert original Ukrainian І to either Cyrillic I or Latin I, depending on context
# 	but only convert that instance, since there may be Ukrainian words with actual Ukrainian І present

my $oldcode = $code; 
my $run = 1; 

while ($run==1) {
	if (($code =~/(.*)(K)(I)(.*)/) || ($code =~ /(.*)(M)(I)(.*)/) ) {
		#print "found KI or MI in $code\n"; 
		$code = $1.$2.$4; # remove I
		$ukrainianN--;
	} else {
		$run = 0; 
	} # end if else matches
} 
my $run2 = 1; 
while ($run2 ==1) {
	if (($code =~/(.*)(I)(K)(.*)/) || ($code =~ /(.*)(I)(M)(.*)/) ) {
		#print "found IK or IM in $code\n"; 
		$code = $1.$3.$4; # remove I
		$ukrainianN--;
	} else {
		$run2 = 0; 
	} # end if else matches
}

if ($oldcode ne $code) {
#print "after considering possible Roman numerals, count of Ukrainian-specific characters becomes $ukrainianN\n"; 
#print "residue code is $code\n";
print "POSSIBLE UKRAINIAN ROMAN NUMERAL: $row\n"; 
} # end if changed

} # end if possible Ukrainian Roman numeral

	my $russianProportion = 0; 
	my $ukrainianProportion = 0; 
	my $shiftedProportion = 0;  
	my $total = $russianN + $nonRussianN + $ukrainianN + $shift848N; 
	if ($total>0) {
		$russianProportion = $russianN/$total;  
		$ukrainianProportion = $ukrainianN/$total; 
		$shiftedProportion = $shift848N/$total; 
	} else {
		#print "ODD: >>$row<< has russianN $russianN, nonRussianN $nonRussianN, ukrainianN $ukrainianN, shifted $shift848N\n"; 
	} 
	
# remove lines with no Russian
# remove lines with significant Ukrainian-specific characters
# remove lines having only isolated Russian characters
# leave blank line when removing a bad row, to preserve parallel text
	my $unionNonRussian = $ukrainianN + $nonRussianN; 
	if ($russianN == 0) {
		print RBADLINES $row."\n";
		print RGOODLINES "\n";
		print EBADLINES $erow."\n";
		print EGOODLINES "\n";
		$badcount++;
		print "bad line (no Russian) >>$row<<\n"; 
	} elsif ($ukrainianProportion > $ukrainianCharacterMax) { 
		print RBADLINES $row."\n";
		print RGOODLINES "\n";
		print EBADLINES $erow."\n";
		print EGOODLINES "\n";
		$ukrainianBadcount++; 
		$badcount++;
		print "bad line (Ukrainian) >>$row<<\n"; 
		# print "SHH Ukrainian? $row\n"; 
#	} elsif ($russianN>$nonRussianN) {
	} elsif ($russianN>$unionNonRussian) {
		print RGOODLINES $row."\n";
		print RBADLINES "\n"; 
		print EGOODLINES $erow."\n";
		print EBADLINES "\n"; 
		$goodcount++;
		if ($couldshift==1) {
			$didshift++; 
			print "ACTUAL SHIFTED ENCODING: $row\n"; 
		} 
	# now consider cases with at least as many Latin as Russian characters
	# must have at least three Russian characters in a row to count as Russian
	# must have at least $min percent Russian 
	} elsif (($code =~ /CCC/) && ($russianProportion>$min))  {
		print RGOODLINES $row."\n";
		print RBADLINES "\n"; 
		print EGOODLINES $erow."\n";
		print EBADLINES "\n"; 
		$goodcount++;
		if ($couldshift==1) {
			$didshift++; 
			print "SHIFTED ENCODING: $row\n"; 
		} 
	} else {
		print RBADLINES $row."\n";
		print RGOODLINES "\n";
		print EBADLINES $erow."\n";
		print EGOODLINES "\n";
		$badcount++;
		$isolateCount++; 
		print "bad line (isolated Russian char) >>$row<<\n"; 
	}# end if isolated Russian character
	
} else {
# blank row on the Russian side
		print RBADLINES $row."\n";
		print RGOODLINES "\n";
		print EBADLINES $erow."\n";
		print EGOODLINES "\n";
		$badcount++;
		$blankcount++; 
		print "bad line (blank) >>$row<<\n"; 
} 
} # end while rows

close INRU;
close RGOODLINES;
close RBADLINES; 

close INEN;
close EGOODLINES;
close EBADLINES; 

print "output files:\n";
print $goodRussian."\n";
print $goodEnglish."\n";
print $badRussian."\n";
print $badEnglish."\n";
print "\n"; 
print "$linenumber total lines\n"; 
print "$goodcount actual Russian lines\n";
print "     including $didshift lines derived from shifted encoding\n"; 
print "$badcount lines with other languages\n";
print "     including $blankcount lines that are blank in the Russian file\n"; 
print "     including $isolateCount isolated Russian characters or words, where the proportion of Russian is less than $min\n";
print "     including $ukrainianBadcount lines that are probably Ukrainian instead of Russian, where the proportion of special Ukrainian characters is greater than $ukrainianCharacterMax\n"; 
print "-------\n"; 
print "next, run normalizeMixedLatinAndCyrillicCharacters.pl on the Russian lines\n";
print "and optionally run normalizeAccentsEncodedWithCyrillicInBorrowedWords.pl on the Russian lines\n"; 
print "also, optionally run normalizeAccentsEncodedWithCyrillic.pl on the non-Russian lines\n"; 

###############################3
# get codepoint
# change codepoint by delta
# generate character for new codepoint
sub deltaF2C() {
my $char = shift;
#print "in deltaF2C with $char\n"; 
my $delta = 848;  # most of the mappings are offset by this amount
my $deltaChar = $char;  # default to input

if (shifted848($char)) {
my $cnum = ord($char); 
#print "cnum = $cnum\n"; 
my $deltaNum = $cnum + $delta;
#print "deltaNum = $deltaNum\n"; 
$deltaChar = chr($deltaNum); 
#print "SHH  changed $char to $deltaChar\n"; 
} # end if in shifted range for Cyrillic; don't convert spaces, digits, punctuation

$deltaChar; 
} # end delta F2C

# note this is restricted to the strictly Russian range
# there could be similarly encoded Ukrainian text, which would include the mappings
#  = 0404	= 0454
# = 0406	= 0456
# = 4047	= 0457
# = 0490	= 0491
# this encoding makes Russian look like "Finnish"
sub shifted848() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if ( ( ($cnum>=0x00C0)&&($cnum<=0x00FF)) || ($cnum==0x00B1) || ($cnum==0x0101)) {
$estne = 1;
#print "SHH  detected shifted character: $c\n"; 
} # end if eng letter char range
$estne;
} # end sub shifted848

sub nonAccented() {
my $char = shift;
# convert accented cyrillic chars to non-accented versions
$char =~   s/\x{00F2}/\x{043E}/g;   # ò becomes о
$char =~   s/\x{00F3}/\x{043E}/g;   # ó becomes о

$char;
} # end sub nonAccented

# restricted to just the letters, not the symbols
sub english() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0041)&&($cnum<=0x007A)) {
$estne = 1;
} # end if eng letter char range
$estne;
} # end sub english

sub cyrillic() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0400)&&($cnum<=0x04FF)) {
$estne = 1;
} # end if 
$estne;
} # end sub cyrillic

# restrict to characters actually used in Russian, not whole Cyrillic range
# Russian range plus [yo] E: ё
sub russian() {
	my $c = shift;
	my $estne = 0;
	#get codepoint
	my $cnum = ord($c);
	#if (($cnum>=0x0400)&&($cnum<=0x04FF)) {
	if ( ( ($cnum>=0x0410)&&($cnum<=0x044F)) || ($cnum==0x0401) || ($cnum==0x0451)) {
		$estne = 1;
	} # end if 
	$estne;
} # end sub russian

# perhaps omit Ukrainian 0406 І  because it can be used in Russian for Roman numerals 
# with lowercased input, worry about  0456 і as well -- but it is needed to distinguish many Ukrainian sentences which do not have the other special characters
sub ukrainianOnly() {
	my $c = shift; 
	my $estne = 0;
	#get codepoint
	my $cnum = ord($c);
	if ( ($cnum==0x0404) ||($cnum==0x0407) ||($cnum==0x0454) ||($cnum==0x0457) ||($cnum==0x0490) ||($cnum==0x0491)  || ($cnum==0x0456) || ($cnum==0x0406)) {
		$estne = 1; 
	} # end if	
	$estne;
} # end ukrainianOnly

# allow here any version of X, I, V
# Latin x X i I v V
# Cyrillic x X i I
# consider M, C, L
sub possibleRomanNumeral() {
	my $c = shift; 
	my $estne = 0;
	#get codepoint
	my $cnum = ord($c);
	if ( ($cnum==0x0406) ||($cnum==0x0456) ||($cnum==0x0069) ||($cnum==0x0049) ||($cnum==0x0445) ||($cnum==0x0425) ||($cnum==0x0078) ||($cnum==0x0058)  || ($cnum==0x0076) || ($cnum==0x0056)) {
		$estne = 1; 
	} # end if	
	$estne;
} # end possibleRomanNumeral

# add others symbols here if needed 
# 000A = line feed
# added soft hyphen 00AD
sub otherAllowed() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if ( ($cnum==0x000A) || ($cnum==0x00AD) 
# || ($cnum==0x0000) 
) {
$estne = 1;
} # end if others char range
$estne;
} # end sub otherAllowed


# Latin, Latin-1 supplement, and 0152 0153 OE oe
sub french() {
my $c = shift;
my $estne = 0;
my $cnum = ord($c);  #get codepoint
if ( (($cnum>=0x0041)&&($cnum<=0x007A)) || (($cnum>=0x00C0)&&($cnum<=0x00FF)) || ($cnum==0x0152) || ($cnum==0x0153) ) {
$estne = 1;
} # end if french char range
$estne;
} # end sub french

