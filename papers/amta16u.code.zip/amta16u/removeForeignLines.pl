#!/usr/bin/perl
#
# given the name of the source and target languages, remove any lines that are all foreign words
# for the ru-en commoncrawl, remove lines that are all French, Ukrainian, etc.
# TODO make a program that removes lines from both files in parallel text
#  perhaps:  set a threshold, since a line might be in the wrong language but contain some words in the correct language.  
# consider words with mixed alphabets to be examples of the majority language
# e.g., words with accented characters:  Danica Simšic within a French line
# e.g., words with mixed Latin and Cyrillic within the Cyrillic:
# e.g., words with accented characters encoded with Cyrillic within a French line:  

#
# removeForeignLines.pl -i INPUT -o OUTPUT -b BADLINES -k LANG1,LANG2
#
# where -k is a list of languages to keep, as defined in the subroutines below
# and -b is a file that lists the lines that are removed
# option -n prints the original line numbers (good for identifying where the file has foreign sections)
#
#
# if the entire line is removed, we output a blank line (this keeps parallel files parallel)
#
# only certain language and/or script names are supported:  
# english, french, arabic, cyrillic, hindi, chinese, greek
# NOTE: use russian for just russian language, use cyrillic for entire cyrillic range
# NOTE: can keep remove Ukrainian from Russian, but not the reverse
# TODO:  finish adding ranges to arabic, chinese
#
# >> to define a new language range, copy and edit the french subroutine, below.
# 
# you may be able to use existing Unicode properties:
# 	InArabic, InCyrillic, InDevanagari, InGreek, etc.
# 	note also InArabicPresentationForms-A, -B, etc. 
# 
# or you may have to define specific ranges:  French = 00C0-00FF
# 	note that additional characters may be needed beyond the main code block
#  	(for French, we add OE 0152 and oe 0153)
#
# sub french() {
# my $c = shift;
# my $estne = 0;
# my $cnum = ord($c);  #get codepoint
# if ( (($cnum>=0x00C0)&&($cnum<=0x00FF)) || ($cnum==0x0152) || ($cnum==0x0153) ) {
# $estne = 1;
# } # end if french char range
# $estne;
# } # end sub french


use strict;
use Getopt::Std;

binmode(STDOUT, ":utf8");

our($opt_i, $opt_o, $opt_b, $opt_k, $opt_n);
getopts("i:o:b:k:n");

if(!$opt_i) {
    die "No input file specified with -i!\n";
}

if(!$opt_o) {
    die "No output file specified with -o!\n";
}

if(!$opt_b) {
    die "No bad character output file specified with -b!\n";
}

if(!$opt_k) {
    die "No languages to keep specified with -k!\n";
}

open (INFILE, $opt_i) or die "$0: Unable to open input file: $opt_i\n";
open (OUTFILE, ">$opt_o") or die "$0: Unable to open output file: $opt_o\n";
open (OUTFILE2, ">$opt_b") or die "$0: Unable to open output file: $opt_b\n";

binmode(INFILE, ":utf8");
binmode(OUTFILE, ":utf8");
binmode(OUTFILE2, ":utf8");

print "infile:  $opt_i\n";
print "outfile: $opt_o\n";
print "outfile2: $opt_b\n";
print "keep languages: $opt_k\n";
print "number lines? $opt_n\n";


# number lines option
my $linenumbering = 0;
if ($opt_n) {
$linenumbering = 1;
} # end if

# parse the list of languages (these must match the subroutines)
my $englishflag = 0;
my $frenchflag = 0;
my $arabicflag = 0;
my $cyrillicflag = 0;
my $russianflag = 0; 
my $ukrainianflag = 0; 
my $greekflag = 0;
my $hindiflag = 0;
my $chineseflag = 0;

my $langlist = $opt_k;

my @langwords = split/,/, $langlist;
for (my $i=0; $i<@langwords; $i++) {
my $wordi = $langwords[$i];

$_ = $wordi;
if (/^english$/i) {
$englishflag =1;
} elsif (/^french$/i) {
$frenchflag = 1;
} elsif (/^arabic$/i) {
$arabicflag = 1;
} elsif (/^cyrillic$/i) {
$cyrillicflag = 1;
} elsif (/^russian$/i) {
$russianflag = 1;
} elsif (/^ukrainian$/i) {
$ukrainianflag = 1;
} elsif (/^greek$/i) {
$greekflag = 1;
} elsif (/^hindi$/i) {
$hindiflag = 1;
} elsif (/^chinese$/i) {
$chineseflag = 1;
} else {
print "unknown language range, $wordi\n";
} # end find word

} # end for word in list

my $badchars = " ";

my $linenumber = 0;
my $wordCount = 0;
my $goodCharMin = 0.8;  # TODO  set this
my $goodWordMin = 0.8;  # TODO  set this
# for the English side of the ru-en commoncrawl, use 0.8 and 0.8

while(my $row = <INFILE>) {

#print "new row: $row\n";
#print "variable badlastword = $badlastword\n";
$linenumber++;
my $badlastword = 0;  
my $goodWordCount = 0;
my $badWordCount = 0; 

$wordCount = 0; 
my @words = split / /, $row;
for (my $j=0; $j<@words; $j++) {
my $wordj = $words[$j];
$wordCount++;
#print "word >>$wordj<<\n";

# if at least one good character, keep
# if all symbols/punc, keep
# if bad letters with attached punc/symbol, toss
# if all bad letters, toss

# abc
# 13,
# друг7,
# друг

my $badword = 1;  #assume it is guilty
my $symbolsonly = 1;  # assume it is all symbols
my $goodCharCount = 0;
my $badCharCount = 0;

my @cs = split //, $wordj;
for (my $i=0; $i<@cs; $i++) {
my $ci = $cs[$i];

# language classes should include letters only, not symbols or numbers
# if the character is in an allowed language, keep checking
if ( 
((english($ci))&($englishflag==1)) || 
((french($ci))&($frenchflag==1)) || 
((arabic($ci))&($arabicflag==1)) || 
((greek($ci))&($greekflag==1)) || 
((cyrillic($ci))&($cyrillicflag==1)) ||
((russian($ci))&($russianflag==1)) ||
((ukrainian($ci))&($ukrainianflag==1)) ||
((hindi($ci))&($hindiflag==1)) ||
((chinese($ci))&($chineseflag==1)) #||
) {
$goodCharCount++; 
$symbolsonly = 0;  # not all symbols/punctuation
} else {
#character is not in an allowed language;  check for symbol,punctuation; if no mitigating factors, count as a bad word



# if new, and if not a number or punctuation symbol, add to bad character list
# note: capital \P = 'not'
# note: currency symbols are included in the set, Symbol
$_ = $ci;
if ( (/\P{Punctuation}/) &&(/\P{Symbol}/) && (!otherAllowed($ci) &&(/\P{Number}/)) ) {
# print "char $ci is not punctuation,symbol,otherAllowed, or number\n";
$badCharCount++; 
$symbolsonly = 0;  # at least one char that is not in target language(s), and not a symbol or punctuation character

# record bad characters for debugging
$_ = $badchars;
# only save new ones
if (!/$ci/) {
$badchars = $badchars.$ci.' ';
# print OUTFILE2 $ci.' ';
} # end if don't already have badchar

} # end if not symbol, punct, etc.
} # end if  allowed character

} # end for char in word

my $goodCharProportion = 1;   # default to acceptance in the case of digits or punctuation
my $totalNonSymbols = $goodCharCount + $badCharCount;
if ($totalNonSymbols >0) {
	$goodCharProportion = $goodCharCount/($totalNonSymbols); 
} 
#print "SHH good character proportion $goodCharProportion\n";

if ($goodCharProportion >= $goodCharMin) {
	$goodWordCount++;
	#print "SHH good word $wordj\n"; 
} else {
	$badWordCount++;  
	#print "SHH bad word $wordj\n"; 
} # end if enough good characters

} # end for words in row

my $goodWordProportion = 0;
my $binaryWordCount = $goodWordCount + $badWordCount; 
if ($binaryWordCount > 0) {
	$goodWordProportion= $goodWordCount/$wordCount; 
} # end if enough good words
#print $row."\n"; 
#print "SHH $goodWordCount good words, $badWordCount bad words, from $binaryWordCount words\nfor a proportion of $goodWordProportion\n";

    chomp $row;
    $row =~ s/\s+/ /g;
    $row =~ s/^\s+//;
    $row =~ s/\s+$//;
    
if ($goodWordProportion >= $goodWordMin) {
#print "SHH keeping >>$row<<\n"; 
# print row

if ($linenumbering) {
print OUTFILE "$linenumber//$row\n";
print OUTFILE2 "$linenumber\n"; # blank line
} else {
print OUTFILE "$row\n";
print OUTFILE2 "\n";  # blank line
} # end if else number the lines with original line numbers

} else {
#bad line:
#print "SHH tossing $row\n"; 

# print a blank line
if ($linenumbering) {
print OUTFILE "$linenumber//\n";
print OUTFILE2 "$linenumber//$row\n"; 
} else {
print OUTFILE "\n";
print OUTFILE2 "$row\n"; 
} # end if else number the lines with original line numbers

} # end if else enough good words to keep the row


} # end while row


close INFILE;
close OUTFILE;
close OUTFILE2;


# TODO -- split Number set into "English" vs. "Arabic" vs. "Chinese" etc.

# now restricted to just the letters, not the symbols
sub english() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0041)&&($cnum<=0x007A)) {
$estne = 1;
} # end if eng letter char range
$estne;
} # end sub english

# don't use englishALL
sub englishALL() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0020)&&($cnum<=0x007E)) {
$estne = 1;
} # end if eng char range
$estne;
} # end sub englishALL

# Latin, Latin-1 supplement, and 0152 0153 OE oe
sub french() {
my $c = shift;
my $estne = 0;
my $cnum = ord($c);  #get codepoint
if ( (($cnum>=0x0041)&&($cnum<=0x007A)) || (($cnum>=0x00C0)&&($cnum<=0x00FF)) || ($cnum==0x0152) || ($cnum==0x0153) ) {
$estne = 1;
} # end if french char range
$estne;
} # end sub french

# TODO add presentation ranges
sub arabic() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0600)&&($cnum<=0x06FF)) {
$estne = 1;
} # end if 
$estne;
} # end sub arabic

sub greek() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0370)&&($cnum<=0x03FF)) {
$estne = 1;
} # end if 
$estne;
} # end sub greek

sub cyrillic() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0400)&&($cnum<=0x04FF)) {
$estne = 1;
} # end if 
$estne;
} # end sub cyrillic

sub ukrainian() {
	my $c = shift;
	my $estne = 0;
	#get codepoint
	my $cnum = ord($c);
	# if in Russian range, excluding 3 chars, or if one of the extra Ukrainian chars
	if  ( (   russian($c) && !russianOnly($c))|| (ukrainianOnly($c)) )  {
		#print "SHH Ukrainian character: $c\n"; 
		$estne = 1;
	} else {
		#print "SHH non-Ukrainian character: $c\n"; 
	}# end if
	$estne;
} # end sub ukrainian

# restrict to characters actually used in Russian, not whole Cyrillic range
# Russian range plus [yo] E: ё
sub russian() {
	my $c = shift;
	my $estne = 0;
	#get codepoint
	my $cnum = ord($c);
	#if (($cnum>=0x0400)&&($cnum<=0x04FF)) {
	if ( ( ($cnum>=0x0410)&&($cnum<=0x044F)) || ($cnum==0x0401) || ($cnum==0x0451)) {
		$estne = 1;
	} # end if 
	$estne;
} # end sub russian

sub russianOnly() {
	my $c = shift;
	my $estne = 0;
	#get codepoint
	my $cnum = ord($c);
	if  ( ($cnum==0x042A) || ($cnum==0x042B) || ($cnum==0x04D) || ($cnum==0x044A) || ($cnum==0x044B) || ($cnum==0x044D)  ) {
		$estne = 1;
	} # end if 
	$estne;
} # end sub russianOnly


# perhaps omit Ukrainian 0406 І  because it can be used in Russian for Roman numerals 
# with lowercased input, worry about  0456 і as well -- but it is needed to distinguish many Ukrainian sentences which do not have the other special characters
sub ukrainianOnly() {
	my $c = shift; 
	my $estne = 0;
	#get codepoint
	my $cnum = ord($c);
	if ( ($cnum==0x0404) ||($cnum==0x0407) ||($cnum==0x0454) ||($cnum==0x0457) ||($cnum==0x0490) ||($cnum==0x0491)  || ($cnum==0x0456) || ($cnum==0x0406)) {
		$estne = 1; 
		#print "     Ukrainian special character, $c\n"; 
	} # end if	
	$estne;
} # end ukrainianOnly

# allow here any version of X, I, V
# Latin x X i I v V
# Cyrillic x X i I
# consider M, C, L
sub possibleRomanNumeral() {
	my $c = shift; 
	my $estne = 0;
	#get codepoint
	my $cnum = ord($c);
	if ( ($cnum==0x0406) ||($cnum==0x0456) ||($cnum==0x0069) ||($cnum==0x0049) ||($cnum==0x0445) ||($cnum==0x0425) ||($cnum==0x0078) ||($cnum==0x0058)  || ($cnum==0x0076) || ($cnum==0x0056)) {
		$estne = 1; 
	} # end if	
	$estne;
} # end possibleRomanNumeral

sub hindi() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0900)&&($cnum<=0x097F)) {
$estne = 1;
} # end if
$estne;
} # end sub hindi

#TODO -- add all the CJK ranges here
sub chinese() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (
(($cnum>=0x4E00)&&($cnum<=0x9FCB))||
(($cnum>=0x3400)&&($cnum<=0x4DB5)) ||
(($cnum>=0xF900)&&($cnum<=0x4FAD9)) # ||
) {
$estne = 1;
} # end if 
$estne;
} # end sub chinese

#TODO add others symbols here if needed 
# include 000A newline, to preserve badlastword value across blank lines
sub otherAllowed() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if ( ($cnum==0x000A) 
# || ($cnum==0x0000) 
) {
$estne = 1;
} # end if others char range
$estne;
} # end sub otherAllowed


# numerals included in the English character range
# 0030-0039 
sub englishNumerals() {
my $c = shift;
my $estne = 0;
#get codepoint
my $cnum = ord($c);
if (($cnum>=0x0030)&&($cnum<=0x0039)) {
$estne = 1;
} # end if num char range
$estne;
} # end sub numerals



# considered limiting numbers to appropriate character sets... not currently used:
 
# now check numbers 
#$_ =$ci;
#if (
# (/\p{Number}/) 
# && (
#( ($englishflag==1)&&(/\p{Latin}/) ) ||  # working with english, have english number
#( ($greekflag==1)&&(/\p{Latin}/) ) ||  # working with greek, have english number
#( ($cyrillicflag==1)&&(/\p{Latin}/) ) ||  # working with cyrillic, have english number
#( ($arabicflag==1)&&(/\p{InArabic}/) ) ||  # working with arabic, have arabic number
#( ($hindiflag==1)&&(/\p{InDevanagari}/) ) ||  # working with hindi, have hindi number
#( ($chineseflag==1)&&(/\p{InCJK}/) ) # ||  # working with chinese, have chinese number
#) 
#) {
#$punctorsymbol = 1;
#print "found (appropriate) number: $ci\n";
#} # end if (appropriate) number
